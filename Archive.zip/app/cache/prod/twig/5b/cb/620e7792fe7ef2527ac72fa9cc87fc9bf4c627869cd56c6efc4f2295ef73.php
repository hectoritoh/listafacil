<?php

/* AppSiteBundle:Default:promociones.html.twig */
class __TwigTemplate_5bcb620e7792fe7ef2527ac72fa9cc87fc9bf4c627869cd56c6efc4f2295ef73 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "
<div class=\"promo\">
  <div class=\"\">
    <div class=\"row\">

      <!-- Red color promo box -->
      <div class=\"col-md-4\">
        <!-- rcolor =  Red color -->
        <div class=\"pbox rcolor\">
          <div class=\"pcol-left\">
            <!-- Image -->
            <a href=\"items.html\">      
              ";
        // line 13
        if (isset($context['assetic']['debug']) && $context['assetic']['debug']) {
            // asset "1d90482_0"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_1d90482_0") : $this->env->getExtension('assets')->getAssetUrl("images/1d90482_promo-1_1.png");
            // line 14
            echo "              <img src=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : null), "html", null, true);
            echo "\" alt=\"Example\" />
              ";
        } else {
            // asset "1d90482"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_1d90482") : $this->env->getExtension('assets')->getAssetUrl("images/1d90482.png");
            echo "              <img src=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : null), "html", null, true);
            echo "\" alt=\"Example\" />
              ";
        }
        unset($context["asset_url"]);
        // line 16
        echo "            </a>
          </div>
          <div class=\"pcol-right\">
            <!-- Title -->
            <p class=\"pmed\"><a href=\"items.html\">HTC One</a></p>
            <!-- Para -->
            <p class=\"psmall\"><a href=\"items.html\">Buy HTC Phones just for \$250. Cheap. Dont miss this offer. Keep it checking for more.</a></p>
          </div>
          <div class=\"clearfix\"></div>
        </div>
      </div>


      <!-- Blue color promo box -->
      <div class=\"col-md-4\">
        <!-- bcolor =  Blue color -->
        <div class=\"pbox bcolor\">
          <div class=\"pcol-left\">
            <a href=\"items.html\">      
              ";
        // line 35
        if (isset($context['assetic']['debug']) && $context['assetic']['debug']) {
            // asset "58f1854_0"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_58f1854_0") : $this->env->getExtension('assets')->getAssetUrl("images/58f1854_promo-2_1.png");
            // line 36
            echo "              <img src=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : null), "html", null, true);
            echo "\" alt=\"Example\" />
              ";
        } else {
            // asset "58f1854"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_58f1854") : $this->env->getExtension('assets')->getAssetUrl("images/58f1854.png");
            echo "              <img src=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : null), "html", null, true);
            echo "\" alt=\"Example\" />
              ";
        }
        unset($context["asset_url"]);
        // line 38
        echo "            </a>
          </div>
          <div class=\"pcol-right\">
            <p class=\"pmed\"><a href=\"items.html\">Blackberry</a></p>
            <p class=\"psmall\"><a href=\"items.html\">Buy Blackberry phones just for \$250. Dont miss this offer. Keep it checking for more.</a></p>
          </div>
          <div class=\"clearfix\"></div>
        </div>
      </div>

      <!-- Green color promo box -->
      <div class=\"col-md-4\">
        <!-- gcolor =  Green Color -->
        <div class=\"pbox gcolor\">
          <div class=\"pcol-left\">
            <a href=\"items.html\">      
              ";
        // line 54
        if (isset($context['assetic']['debug']) && $context['assetic']['debug']) {
            // asset "f432d42_0"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_f432d42_0") : $this->env->getExtension('assets')->getAssetUrl("images/f432d42_promo-3_1.png");
            // line 55
            echo "              <img src=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : null), "html", null, true);
            echo "\" alt=\"Example\" />
              ";
        } else {
            // asset "f432d42"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_f432d42") : $this->env->getExtension('assets')->getAssetUrl("images/f432d42.png");
            echo "              <img src=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : null), "html", null, true);
            echo "\" alt=\"Example\" />
              ";
        }
        unset($context["asset_url"]);
        // line 57
        echo "            </a>
          </div>
          <div class=\"pcol-right\">
            <p class=\"pmed\"><a href=\"items.html\">Nokia Lumia</a></p>
            <p class=\"psmall\"><a href=\"items.html\">Buy Nokia Lumia Phones just for \$200. Dont miss  offer. Keep it checking for more.</a></p>
          </div>
          <div class=\"clearfix\"></div>
        </div>
      </div>

    </div>
  </div>
</div>";
    }

    public function getTemplateName()
    {
        return "AppSiteBundle:Default:promociones.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  126 => 57,  90 => 38,  76 => 36,  37 => 14,  451 => 222,  433 => 220,  408 => 197,  394 => 196,  390 => 195,  370 => 177,  356 => 176,  352 => 175,  344 => 169,  330 => 168,  326 => 167,  302 => 145,  288 => 144,  284 => 143,  262 => 123,  248 => 122,  244 => 121,  234 => 113,  216 => 110,  191 => 87,  145 => 74,  120 => 51,  65 => 25,  52 => 17,  84 => 28,  34 => 14,  480 => 162,  474 => 161,  469 => 158,  461 => 155,  457 => 153,  453 => 151,  444 => 149,  440 => 148,  437 => 221,  435 => 146,  430 => 144,  427 => 143,  423 => 142,  413 => 134,  409 => 132,  407 => 131,  402 => 130,  398 => 129,  393 => 126,  387 => 122,  384 => 121,  381 => 120,  379 => 119,  374 => 116,  368 => 112,  365 => 111,  362 => 110,  360 => 109,  355 => 106,  341 => 105,  337 => 103,  322 => 101,  314 => 99,  312 => 98,  309 => 97,  305 => 95,  298 => 91,  294 => 90,  285 => 89,  283 => 88,  278 => 86,  268 => 85,  264 => 84,  258 => 81,  252 => 80,  247 => 78,  241 => 77,  229 => 73,  220 => 111,  214 => 69,  177 => 86,  169 => 60,  140 => 55,  132 => 51,  128 => 49,  111 => 37,  107 => 36,  61 => 24,  273 => 96,  269 => 94,  254 => 92,  246 => 90,  243 => 88,  240 => 86,  238 => 85,  235 => 74,  230 => 82,  227 => 81,  224 => 71,  221 => 77,  219 => 76,  217 => 75,  208 => 68,  204 => 72,  179 => 69,  159 => 61,  143 => 56,  135 => 53,  131 => 52,  119 => 42,  108 => 54,  102 => 48,  71 => 23,  67 => 15,  63 => 15,  59 => 14,  47 => 9,  38 => 15,  94 => 28,  89 => 20,  85 => 25,  79 => 27,  75 => 17,  68 => 22,  56 => 16,  50 => 12,  29 => 6,  87 => 25,  72 => 35,  55 => 15,  21 => 2,  26 => 6,  98 => 31,  93 => 28,  88 => 6,  78 => 21,  46 => 7,  27 => 7,  40 => 11,  44 => 12,  35 => 5,  31 => 8,  43 => 8,  41 => 7,  28 => 3,  201 => 92,  196 => 90,  183 => 82,  171 => 61,  166 => 71,  163 => 77,  158 => 67,  156 => 66,  151 => 63,  142 => 59,  138 => 54,  136 => 56,  123 => 47,  121 => 46,  117 => 44,  115 => 43,  105 => 40,  101 => 32,  91 => 27,  69 => 25,  66 => 15,  62 => 23,  49 => 19,  24 => 4,  32 => 4,  25 => 5,  22 => 2,  19 => 1,  209 => 82,  203 => 78,  199 => 67,  193 => 73,  189 => 71,  187 => 84,  182 => 66,  176 => 64,  173 => 85,  168 => 72,  164 => 59,  162 => 59,  154 => 58,  149 => 75,  147 => 58,  144 => 49,  141 => 48,  133 => 55,  130 => 41,  125 => 44,  122 => 43,  116 => 41,  112 => 55,  109 => 34,  106 => 49,  103 => 32,  99 => 31,  95 => 28,  92 => 21,  86 => 28,  82 => 22,  80 => 19,  73 => 19,  64 => 21,  60 => 13,  57 => 11,  54 => 10,  51 => 16,  48 => 13,  45 => 9,  42 => 7,  39 => 9,  36 => 10,  33 => 13,  30 => 7,);
    }
}
