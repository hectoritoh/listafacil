<?php

/* AppSiteBundle:Pages:ver.categoria.html.twig */
class __TwigTemplate_ab0416b1edcf17bd7f03177c289958639dd627fadccbebfb2d03640eeecc3ba2 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("AppSiteBundle:Default:template.html.twig");

        $this->blocks = array(
            'slider' => array($this, 'block_slider'),
            'titulo_contenido' => array($this, 'block_titulo_contenido'),
            'contenido' => array($this, 'block_contenido'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "AppSiteBundle:Default:template.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 4
    public function block_slider($context, array $blocks = array())
    {
    }

    // line 8
    public function block_titulo_contenido($context, array $blocks = array())
    {
        // line 9
        echo "<span class=\"title\"> <a href=\"";
        echo $this->env->getExtension('routing')->getPath("home");
        echo "\">HOME</a>   >   ";
        echo twig_escape_filter($this->env, twig_upper_filter($this->env, $this->getAttribute((isset($context["categoria"]) ? $context["categoria"] : null), "nombre")), "html", null, true);
        echo " </span>    
";
    }

    // line 14
    public function block_contenido($context, array $blocks = array())
    {
        // line 15
        echo "
";
        // line 16
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["pagination"]) ? $context["pagination"] : null));
        foreach ($context['_seq'] as $context["_key"] => $context["producto"]) {
            // line 17
            echo "
<div class=\"col-lg-4 col-sm-4 hero-feature text-center\">
  <div class=\"thumbnail\">
    <a href=\"detail.html\" class=\"link-p\">

     <img src=\"";
            // line 22
            echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl(("uploads/productos/" . $this->getAttribute((isset($context["producto"]) ? $context["producto"] : null), "imagen"))), "html", null, true);
            echo "\" class=\"img-responsive\" alt=\"";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["producto"]) ? $context["producto"] : null), "nombre"), "html", null, true);
            echo "\" />
   </a>
   <div class=\"caption prod-caption\">
    <h4><a href=\"detail.html\">";
            // line 25
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["producto"]) ? $context["producto"] : null), "nombre"), "html", null, true);
            echo "</a></h4>
    <!-- <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aut, minima!</p> -->
    <p>
      <div class=\"btn-group\"  style=\"width:100%;\" >
        <!-- <a href=\"#\" class=\"btn btn-default\">\$ 122.51</a> -->
        <a href=\"#\"  style=\"width:100%;\"  class=\"btn btn-primary\"><i class=\"fa fa-shopping-cart\"></i> VER</a>
      </div>
    </p>
  </div>
</div>
</div>

";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['producto'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 38
        echo "


<div class=\"container-fluid\">

  <div class=\"row\">
    <div class=\"navigation\">
      ";
        // line 45
        echo $this->env->getExtension('knp_pagination')->render((isset($context["pagination"]) ? $context["pagination"] : null));
        echo "
    </div>
  </div>
</div>




";
    }

    public function getTemplateName()
    {
        return "AppSiteBundle:Pages:ver.categoria.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  100 => 45,  53 => 16,  160 => 117,  152 => 111,  175 => 143,  172 => 124,  155 => 112,  327 => 155,  324 => 154,  319 => 149,  316 => 148,  279 => 49,  266 => 40,  256 => 188,  218 => 186,  188 => 157,  186 => 154,  180 => 150,  178 => 148,  81 => 49,  74 => 46,  126 => 57,  90 => 28,  76 => 36,  37 => 14,  451 => 222,  433 => 220,  408 => 197,  394 => 196,  390 => 195,  370 => 177,  356 => 176,  352 => 175,  344 => 169,  330 => 168,  326 => 167,  302 => 145,  288 => 144,  284 => 143,  262 => 123,  248 => 122,  244 => 121,  234 => 113,  216 => 110,  191 => 87,  145 => 74,  120 => 51,  65 => 25,  52 => 17,  84 => 28,  34 => 4,  480 => 162,  474 => 161,  469 => 158,  461 => 155,  457 => 153,  453 => 151,  444 => 149,  440 => 148,  437 => 221,  435 => 146,  430 => 144,  427 => 143,  423 => 142,  413 => 134,  409 => 132,  407 => 131,  402 => 130,  398 => 129,  393 => 126,  387 => 122,  384 => 121,  381 => 120,  379 => 119,  374 => 116,  368 => 112,  365 => 111,  362 => 110,  360 => 109,  355 => 106,  341 => 105,  337 => 103,  322 => 101,  314 => 99,  312 => 98,  309 => 97,  305 => 95,  298 => 91,  294 => 90,  285 => 89,  283 => 88,  278 => 86,  268 => 85,  264 => 84,  258 => 81,  252 => 80,  247 => 78,  241 => 77,  229 => 73,  220 => 111,  214 => 178,  177 => 86,  169 => 123,  140 => 55,  132 => 51,  128 => 49,  111 => 37,  107 => 82,  61 => 24,  273 => 96,  269 => 41,  254 => 92,  246 => 90,  243 => 88,  240 => 86,  238 => 85,  235 => 74,  230 => 82,  227 => 81,  224 => 71,  221 => 77,  219 => 76,  217 => 75,  208 => 68,  204 => 72,  179 => 69,  159 => 61,  143 => 56,  135 => 53,  131 => 52,  119 => 42,  108 => 54,  102 => 68,  71 => 23,  67 => 15,  63 => 15,  59 => 14,  47 => 14,  38 => 9,  94 => 61,  89 => 55,  85 => 38,  79 => 27,  75 => 30,  68 => 22,  56 => 16,  50 => 15,  29 => 6,  87 => 25,  72 => 25,  55 => 16,  21 => 2,  26 => 6,  98 => 31,  93 => 28,  88 => 6,  78 => 21,  46 => 7,  27 => 7,  40 => 8,  44 => 12,  35 => 8,  31 => 3,  43 => 8,  41 => 7,  28 => 3,  201 => 168,  196 => 90,  183 => 82,  171 => 61,  166 => 137,  163 => 118,  158 => 131,  156 => 66,  151 => 63,  142 => 59,  138 => 54,  136 => 56,  123 => 47,  121 => 46,  117 => 90,  115 => 43,  105 => 40,  101 => 32,  91 => 38,  69 => 25,  66 => 15,  62 => 23,  49 => 19,  24 => 4,  32 => 9,  25 => 5,  22 => 1,  19 => 1,  209 => 82,  203 => 169,  199 => 67,  193 => 73,  189 => 71,  187 => 84,  182 => 66,  176 => 64,  173 => 85,  168 => 72,  164 => 59,  162 => 59,  154 => 58,  149 => 75,  147 => 58,  144 => 49,  141 => 48,  133 => 55,  130 => 41,  125 => 44,  122 => 43,  116 => 41,  112 => 55,  109 => 34,  106 => 49,  103 => 32,  99 => 67,  95 => 28,  92 => 21,  86 => 28,  82 => 22,  80 => 19,  73 => 19,  64 => 22,  60 => 13,  57 => 17,  54 => 10,  51 => 16,  48 => 13,  45 => 12,  42 => 11,  39 => 10,  36 => 7,  33 => 8,  30 => 4,);
    }
}
