<?php

/* AppSiteBundle:Default:template.html.twig */
class __TwigTemplate_03cf0e362d2cb875f532644531464aa1003d737b0f0a352053e31aa4733e604b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'slider' => array($this, 'block_slider'),
            'titulo_contenido' => array($this, 'block_titulo_contenido'),
            'contenido' => array($this, 'block_contenido'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!DOCTYPE html>
<html lang=\"es\">
<head>
  <meta charset=\"utf-8\">
  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">
  <meta name=\"description\" content=\"\">
  <meta name=\"author\" content=\"\">
  <title>Lista facil</title>
  ";
        // line 9
        if (isset($context['assetic']['debug']) && $context['assetic']['debug']) {
            // asset "778cb3e_0"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_778cb3e_0") : $this->env->getExtension('assets')->getAssetUrl("css/778cb3e_bootstrap_1.css");
            // line 16
            echo "  <link rel=\"stylesheet\" href=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : null), "html", null, true);
            echo "\" />
  ";
            // asset "778cb3e_1"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_778cb3e_1") : $this->env->getExtension('assets')->getAssetUrl("css/778cb3e_font-awesome.min_2.css");
            echo "  <link rel=\"stylesheet\" href=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : null), "html", null, true);
            echo "\" />
  ";
            // asset "778cb3e_2"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_778cb3e_2") : $this->env->getExtension('assets')->getAssetUrl("css/778cb3e_jquery.boxslider_3.css");
            echo "  <link rel=\"stylesheet\" href=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : null), "html", null, true);
            echo "\" />
  ";
            // asset "778cb3e_3"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_778cb3e_3") : $this->env->getExtension('assets')->getAssetUrl("css/778cb3e_style_4.css");
            echo "  <link rel=\"stylesheet\" href=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : null), "html", null, true);
            echo "\" />
  ";
            // asset "778cb3e_4"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_778cb3e_4") : $this->env->getExtension('assets')->getAssetUrl("css/778cb3e_app_5.css");
            echo "  <link rel=\"stylesheet\" href=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : null), "html", null, true);
            echo "\" />
  ";
        } else {
            // asset "778cb3e"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_778cb3e") : $this->env->getExtension('assets')->getAssetUrl("css/778cb3e.css");
            echo "  <link rel=\"stylesheet\" href=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : null), "html", null, true);
            echo "\" />
  ";
        }
        unset($context["asset_url"]);
        // line 17
        echo " 
</head>
<body>

  <header>
    ";
        // line 22
        $this->env->loadTemplate("AppSiteBundle:Default:header.html.twig")->display($context);
        echo "     
  </header>


  <!-- Navigation -->
  <nav class=\"navbar navbar-inverse\" role=\"navigation\">       
   ";
        // line 28
        $this->env->loadTemplate("AppSiteBundle:Default:navigation.html.twig")->display($context);
        echo "     
 </nav>
  <!-- End Navigation -->





 <div class=\"container main-container\">



  ";
        // line 40
        $this->displayBlock('slider', $context, $blocks);
        // line 82
        echo "

  <div class=\"row\">
    <div class=\"col-lg-3 col-md-3 col-sm-12\">

      <!-- Categories -->
      <div class=\"col-lg-12 col-md-12 col-sm-6\">
       
       ";
        // line 90
        echo $this->env->getExtension('http_kernel')->renderFragment($this->env->getExtension('http_kernel')->controller("AppSiteBundle:Default:getCategorias"));
        echo "

      </div>
      <!-- End Categories -->





      <!-- Best Seller -->
      <div class=\"col-lg-12 col-md-12 col-sm-6\">
        <div class=\"no-padding\">
          <span class=\"title\">BEST SELLER</span>
        </div>
        <div class=\"hero-feature\">
          <div class=\"thumbnail text-center\">
            <a href=\"detail.html\" class=\"link-p\">
              <img src=\"images/product-8.jpg\" alt=\"\">
            </a>
            <div class=\"caption prod-caption\">
              <h4><a href=\"detail.html\">Penn State College T-Shirt</a></h4>
              <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aut, minima!</p>
              <p>
                <div class=\"btn-group\">
                  <a href=\"#\" class=\"btn btn-default\">\$ 528.96</a>
                  <a href=\"#\" class=\"btn btn-primary\"><i class=\"fa fa-shopping-cart\"></i> Buy</a>
                </div>
              </p>
            </div>
          </div>
        </div>
        <div class=\"hero-feature hidden-sm\">
          <div class=\"thumbnail text-center\">
            <a href=\"detail.html\" class=\"link-p\">
              <img src=\"images/product-9.jpg\" alt=\"\">
            </a>
            <div class=\"caption prod-caption\">
              <h4><a href=\"detail.html\">Ohio State College T-Shirt</a></h4>
              <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aut, minima!</p>
              <p>
                <div class=\"btn-group\">
                  <a href=\"#\" class=\"btn btn-default\">\$ 924.25</a>
                  <a href=\"#\" class=\"btn btn-primary\"><i class=\"fa fa-shopping-cart\"></i> Buy</a>
                </div>
              </p>
            </div>
          </div>
        </div>
      </div>
      <!-- End Best Seller -->

    </div>

    <div class=\"clearfix visible-sm\"></div>

    <!-- Featured -->
    <div class=\"col-lg-9 col-md-9 col-sm-12\">
      <div class=\"col-lg-12 col-sm-12\">
        ";
        // line 148
        $this->displayBlock('titulo_contenido', $context, $blocks);
        // line 150
        echo "        
      </div>


  ";
        // line 154
        $this->displayBlock('contenido', $context, $blocks);
        // line 157
        echo "
 
    <div class=\"clearfix visible-sm\"></div>

   


  </div>
</div>

<footer>
  ";
        // line 168
        $this->env->loadTemplate("AppSiteBundle:Default:footer.html.twig")->display($context);
        // line 169
        echo "</footer>

<a href=\"#top\" class=\"back-top text-center\" onclick=\"\$('body,html').animate({scrollTop:0},500); return false\">
  <i class=\"fa fa-angle-double-up\"></i>
</a>




";
        // line 178
        if (isset($context['assetic']['debug']) && $context['assetic']['debug']) {
            // asset "45c404f_0"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_45c404f_0") : $this->env->getExtension('assets')->getAssetUrl("js/45c404f_jquery_1.js");
            // line 186
            echo "  <script type=\"text/javascript\" src=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : null), "html", null, true);
            echo "\"></script>
  ";
            // asset "45c404f_1"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_45c404f_1") : $this->env->getExtension('assets')->getAssetUrl("js/45c404f_bootstrap_2.js");
            echo "  <script type=\"text/javascript\" src=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : null), "html", null, true);
            echo "\"></script>
  ";
            // asset "45c404f_2"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_45c404f_2") : $this->env->getExtension('assets')->getAssetUrl("js/45c404f_jquery.bxslider.min_3.js");
            echo "  <script type=\"text/javascript\" src=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : null), "html", null, true);
            echo "\"></script>
  ";
            // asset "45c404f_3"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_45c404f_3") : $this->env->getExtension('assets')->getAssetUrl("js/45c404f_jquery.blImageCenter_4.js");
            echo "  <script type=\"text/javascript\" src=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : null), "html", null, true);
            echo "\"></script>
  ";
            // asset "45c404f_4"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_45c404f_4") : $this->env->getExtension('assets')->getAssetUrl("js/45c404f_mimity_5.js");
            echo "  <script type=\"text/javascript\" src=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : null), "html", null, true);
            echo "\"></script>
  ";
        } else {
            // asset "45c404f"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_45c404f") : $this->env->getExtension('assets')->getAssetUrl("js/45c404f.js");
            echo "  <script type=\"text/javascript\" src=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : null), "html", null, true);
            echo "\"></script>
  ";
        }
        unset($context["asset_url"]);
        // line 188
        echo "



</body>
</html>
<!-- Localized -->";
    }

    // line 40
    public function block_slider($context, array $blocks = array())
    {
        // line 41
        echo "      
  

  <div class=\"row\">

    <!-- Slider -->
    <div class=\"col-lg-9 col-md-12\">

      ";
        // line 49
        echo $this->env->getExtension('http_kernel')->renderFragment($this->env->getExtension('http_kernel')->controller("AppSiteBundle:Default:getSlider"));
        echo "

    </div>


    <!-- End Slider -->

    <!-- Product Selection, visible only on large desktop -->
    <div class=\"col-lg-3 visible-lg\">
      <div class=\"row text-center\">
        <div class=\"col-lg-12 col-md-12 hero-feature\">
          <div class=\"thumbnail\">
            <a href=\"detail.html\" class=\"link-p first-p\">
              <img src=\"images/product-1.jpg\" alt=\"\">
            </a>
            <div class=\"caption prod-caption\">
              <h4><a href=\"detail.html\">Funkalicious Print T-Shirt</a></h4>
              <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aut, minima!</p>
              <p>
                <div class=\"btn-group\">
                  <a href=\"#\" class=\"btn btn-default\">\$ 928.96</a>
                  <a href=\"#\" class=\"btn btn-primary\"><i class=\"fa fa-shopping-cart\"></i> Buy</a>
                </div>
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- End Product Selection -->
  </div>

  ";
    }

    // line 148
    public function block_titulo_contenido($context, array $blocks = array())
    {
        // line 149
        echo "          <span class=\"title\">ÚLTIMOS PRODCUTOS</span>    
        ";
    }

    // line 154
    public function block_contenido($context, array $blocks = array())
    {
        // line 155
        echo "      
  ";
    }

    public function getTemplateName()
    {
        return "AppSiteBundle:Default:template.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  327 => 155,  324 => 154,  319 => 149,  316 => 148,  279 => 49,  266 => 40,  256 => 188,  218 => 186,  188 => 157,  186 => 154,  180 => 150,  178 => 148,  81 => 22,  74 => 17,  126 => 57,  90 => 28,  76 => 36,  37 => 14,  451 => 222,  433 => 220,  408 => 197,  394 => 196,  390 => 195,  370 => 177,  356 => 176,  352 => 175,  344 => 169,  330 => 168,  326 => 167,  302 => 145,  288 => 144,  284 => 143,  262 => 123,  248 => 122,  244 => 121,  234 => 113,  216 => 110,  191 => 87,  145 => 74,  120 => 51,  65 => 25,  52 => 17,  84 => 28,  34 => 14,  480 => 162,  474 => 161,  469 => 158,  461 => 155,  457 => 153,  453 => 151,  444 => 149,  440 => 148,  437 => 221,  435 => 146,  430 => 144,  427 => 143,  423 => 142,  413 => 134,  409 => 132,  407 => 131,  402 => 130,  398 => 129,  393 => 126,  387 => 122,  384 => 121,  381 => 120,  379 => 119,  374 => 116,  368 => 112,  365 => 111,  362 => 110,  360 => 109,  355 => 106,  341 => 105,  337 => 103,  322 => 101,  314 => 99,  312 => 98,  309 => 97,  305 => 95,  298 => 91,  294 => 90,  285 => 89,  283 => 88,  278 => 86,  268 => 85,  264 => 84,  258 => 81,  252 => 80,  247 => 78,  241 => 77,  229 => 73,  220 => 111,  214 => 178,  177 => 86,  169 => 60,  140 => 55,  132 => 51,  128 => 49,  111 => 37,  107 => 82,  61 => 24,  273 => 96,  269 => 41,  254 => 92,  246 => 90,  243 => 88,  240 => 86,  238 => 85,  235 => 74,  230 => 82,  227 => 81,  224 => 71,  221 => 77,  219 => 76,  217 => 75,  208 => 68,  204 => 72,  179 => 69,  159 => 61,  143 => 56,  135 => 53,  131 => 52,  119 => 42,  108 => 54,  102 => 48,  71 => 23,  67 => 15,  63 => 15,  59 => 14,  47 => 9,  38 => 15,  94 => 28,  89 => 20,  85 => 25,  79 => 27,  75 => 17,  68 => 22,  56 => 16,  50 => 12,  29 => 6,  87 => 25,  72 => 35,  55 => 15,  21 => 2,  26 => 6,  98 => 31,  93 => 28,  88 => 6,  78 => 21,  46 => 7,  27 => 7,  40 => 11,  44 => 12,  35 => 5,  31 => 8,  43 => 8,  41 => 7,  28 => 3,  201 => 168,  196 => 90,  183 => 82,  171 => 61,  166 => 71,  163 => 77,  158 => 67,  156 => 66,  151 => 63,  142 => 59,  138 => 54,  136 => 56,  123 => 47,  121 => 46,  117 => 90,  115 => 43,  105 => 40,  101 => 32,  91 => 27,  69 => 25,  66 => 15,  62 => 23,  49 => 19,  24 => 4,  32 => 9,  25 => 5,  22 => 1,  19 => 1,  209 => 82,  203 => 169,  199 => 67,  193 => 73,  189 => 71,  187 => 84,  182 => 66,  176 => 64,  173 => 85,  168 => 72,  164 => 59,  162 => 59,  154 => 58,  149 => 75,  147 => 58,  144 => 49,  141 => 48,  133 => 55,  130 => 41,  125 => 44,  122 => 43,  116 => 41,  112 => 55,  109 => 34,  106 => 49,  103 => 32,  99 => 31,  95 => 28,  92 => 21,  86 => 28,  82 => 22,  80 => 19,  73 => 19,  64 => 21,  60 => 13,  57 => 11,  54 => 10,  51 => 16,  48 => 13,  45 => 12,  42 => 7,  39 => 9,  36 => 16,  33 => 8,  30 => 7,);
    }
}
