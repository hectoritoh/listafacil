<?php

/* AppSiteBundle:Pages:ver.producto.html.twig */
class __TwigTemplate_2a8c570e96f210b909e79a8f69bdf73a95f0ccc3651c906bb7cb9948fdff3aaa extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("AppSiteBundle:Default:template.html.twig");

        $this->blocks = array(
            'slider' => array($this, 'block_slider'),
            'promociones' => array($this, 'block_promociones'),
            'contenido' => array($this, 'block_contenido'),
            'js_adicional' => array($this, 'block_js_adicional'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "AppSiteBundle:Default:template.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 7
    public function block_slider($context, array $blocks = array())
    {
    }

    // line 11
    public function block_promociones($context, array $blocks = array())
    {
    }

    // line 15
    public function block_contenido($context, array $blocks = array())
    {
        // line 16
        echo "
<!-- Items -->

<div class=\"items\">
  <div class=\"container\">
    <div class=\"row\">

      <!-- Sidebar -->
      <div class=\"col-md-4 col-sm-4 hidden-xs\">

        <h5 class=\"title\">Categorias</h5>
        <!-- Sidebar navigation -->
        <nav>
          <ul id=\"nav\">
            <!-- Main menu. Use the class \"has_sub\" to \"li\" tag if it has submenu. -->
         

          ";
        // line 33
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["categorias"]) ? $context["categorias"] : null));
        $context['loop'] = array(
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        );
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["categoria"]) {
            echo "    
               <li class=\"has_sub categoria_list\"    ";
            // line 34
            if (($this->getAttribute((isset($context["loop"]) ? $context["loop"] : null), "index") > 5)) {
                echo "      style=\"display:none;\"  ";
            }
            echo " >
                  <a href=\"";
            // line 35
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("ver_categoria", array("id_categoria" => $this->getAttribute((isset($context["categoria"]) ? $context["categoria"] : null), "id"))), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["categoria"]) ? $context["categoria"] : null), "nombre"), "html", null, true);
            echo "</a>
               </li>
          ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['categoria'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 38
        echo " 
<!--             <li class=\"has_sub\"><a href=\"#\">Tablet</a>
              <ul>
                <li><a href=\"items.html\">Samsung</a></li>
                <li><a href=\"items.html\">Apple</a></li>
                <li><a href=\"items.html\">Motorola</a></li>
              </ul>
            </li>
 -->
           
          </ul>
          <a href=\"#\"  onclick=\"\$('.categoria_list').show('fast')\" >  Ver mas categorias </a>
        </nav>
        <br />
        <!-- Sidebar items (featured items)-->

        <!-- AQUI VAN LOS PRODUCTOS PROMOCIONADOS
        productos.promocionados.html.twig
 -->
        <!-- Sidebar items (featured items)-->

      

      </div>

      <!-- Main content -->

      <div class=\"col-md-8 col-sm-8\">

        <!-- Breadcrumbs -->
        <ul class=\"breadcrumb\">
          <li><a href=\"index.html\">Home</a> <span class=\"divider\">/</span></li>
          <li><a href=\"items.html\">";
        // line 70
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["producto"]) ? $context["producto"] : null), "categoria"), "nombre"), "html", null, true);
        echo "</a> <span class=\"divider\">/</span></li>
          <li class=\"active\">";
        // line 71
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["producto"]) ? $context["producto"] : null), "nombre"), "html", null, true);
        echo "</li>
        </ul>

        <!-- Product details -->

        <div class=\"product-main\">
          <div class=\"row\">
            <div class=\"col-md-6 col-sm-6\">

              <!-- Image. Flex slider -->
              <div class=\"product-slider\">
                <div class=\"product-image-slider flexslider\">
                  <ul class=\"slides\">
                    <!-- Each slide should be enclosed inside li tag. -->

                    <!-- Slide #1 -->
                    <li>
                      <img src=\"";
        // line 88
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl(("uploads/productos/" . $this->getAttribute((isset($context["producto"]) ? $context["producto"] : null), "imagen"))), "html", null, true);
        echo "\" alt=\"";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["producto"]) ? $context["producto"] : null), "descripcion"), "html", null, true);
        echo "\"/>
                    </li>



                  </ul>
                </div>
              </div>

            </div>
            <div class=\"col-md-6 col-sm-6\">
              <!-- Title -->
              <h4 class=\"title\">";
        // line 100
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["producto"]) ? $context["producto"] : null), "nombre"), "html", null, true);
        echo "</h4>
              <h5>Precio : \$";
        // line 101
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["producto"]) ? $context["producto"] : null), "precio"), "html", null, true);
        echo "</h5>
              <p>Disponibilidad : En stock</p>
              <!-- Dropdown menu -->
              <div class=\"form-group\">                               
                <select class=\"form-control\">
                  <option>Color</option>
                  <option>Black</option>
                  <option>White</option>
                  <option>Grey</option>
                </select>  
              </div>

              <!-- Quantity and add to cart button -->

              <div class=\"row\">
               <div class=\"col-md-6\">
                <div class=\"input-group\">
                  <input type=\"text\" class=\"form-control input-sm\" value=\"2\">
                  <span class=\"input-group-btn\">
                   <button class=\"btn btn-default btn-sm\" type=\"button\">Add to Cart</button>
                 </span>\t\t\t\t\t\t\t\t  
               </div>
             </div>
           </div>

           <!-- Add to wish list -->
           <a href=\"wish-list.html\">+ Agregar a wish list</a>


         </div>
       </div>
     </div>

     <br />

     <!-- Description, specs and review -->

     <ul class=\"nav nav-tabs\">
      <!-- Use uniqe name for \"href\" in below anchor tags -->
      <li class=\"active\"><a href=\"#tab1\" data-toggle=\"tab\">Description</a></li>
      <li><a href=\"#tab2\" data-toggle=\"tab\">Especificaciones</a></li>
      <li><a href=\"#tab3\" data-toggle=\"tab\">Comentarios(0)</a></li>
    </ul>

    <!-- Tab Content -->
    <div class=\"tab-content\">
      <!-- Description -->
      <div class=\"tab-pane active\" id=\"tab1\">
        <h5>";
        // line 149
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["producto"]) ? $context["producto"] : null), "nombre"), "html", null, true);
        echo "</h5>
        <p>";
        // line 150
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["producto"]) ? $context["producto"] : null), "descripcion"), "html", null, true);
        echo "</p>
  <!--       <h6>Caracteristicas</h6>
        <ul>
          <li>Etiam adipiscing posuere justo, nec iaculis justo dictum non</li>
          <li>Cras tincidunt mi non arcu hendrerit eleifend</li>
          <li>Aenean ullamcorper justo tincidunt justo aliquet et lobortis diam faucibus</li>
          <li>Maecenas hendrerit neque id ante dictum mattis</li>
          <li>Vivamus non neque lacus, et cursus tortor</li>
        </ul> -->
      </div>

      <!-- Sepcs -->
      <div class=\"tab-pane\" id=\"tab2\">

        <h5 class=\"title\">Especificaciones de productos</h5>
        <table class=\"table table-striped tcart\">
          <tbody>
            <tr>
              <td><strong>Caracteristica</strong></td>
              <td>valor caracteristica</td>
            </tr>
            <tr>
              <td><strong>Caracteristica</strong></td>
              <td>valor caracteristica</td>
            </tr>

                                                                                                        
          </tbody>
        </table>

      </div>

      <!-- Review -->
      <div class=\"tab-pane\" id=\"tab3\">
        <h5>Comentarios</h5>
        <div class=\"item-review\">
          <h5>Ravi Kumar - <span class=\"color\">4/5</span></h5>
          <p class=\"rmeta\">27/1/2012</p>
          <p>Suspendisse potenti. Morbi ac felis nec mauris imperdiet fermentum. Aenean sodales augue ac lacus hendrerit sed rhoncus erat hendrerit. Vivamus vel ultricies elit. Curabitur lacinia nulla vel tellus elementum non mollis justo aliquam.</p>
        </div>

        <hr />
        <h5 class=\"title\">Escribe un comentario</h5>

        <div class=\"form form-small\">

        ";
        // line 196
        echo $this->env->getExtension('actions')->renderUri($this->env->getExtension('http_kernel')->controller("AppSiteBundle:Default:comentar"), array());
        // line 197
        echo "

      </div> 

    </div>

  </div>

</div>                                                                    



</div>
</div>
</div>

<!-- Recent items carousel starts -->









";
    }

    // line 227
    public function block_js_adicional($context, array $blocks = array())
    {
        // line 228
        echo "    

    <script type=\"text/javascript\">

    \$(document).ready(  function(){

        \$(\".rating\").raty({
          starOff:\"/listafacil/web/bundles/appsite/img/star-off.png\",
          starOn:\"/listafacil/web/bundles/appsite/img/star-on.png\"
        });

    } );

    </script>


";
    }

    public function getTemplateName()
    {
        return "AppSiteBundle:Pages:ver.producto.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  325 => 228,  292 => 197,  290 => 196,  237 => 149,  165 => 88,  100 => 45,  53 => 16,  160 => 117,  152 => 111,  175 => 143,  172 => 124,  155 => 112,  327 => 155,  324 => 154,  319 => 149,  316 => 148,  279 => 49,  266 => 40,  256 => 188,  218 => 186,  188 => 157,  186 => 101,  180 => 150,  178 => 148,  81 => 49,  74 => 46,  126 => 57,  90 => 28,  76 => 36,  37 => 14,  451 => 222,  433 => 220,  408 => 197,  394 => 196,  390 => 195,  370 => 177,  356 => 176,  352 => 175,  344 => 169,  330 => 168,  326 => 167,  302 => 145,  288 => 144,  284 => 143,  262 => 123,  248 => 122,  244 => 121,  234 => 113,  216 => 110,  191 => 87,  145 => 71,  120 => 51,  65 => 25,  52 => 17,  84 => 28,  34 => 4,  480 => 162,  474 => 161,  469 => 158,  461 => 155,  457 => 153,  453 => 151,  444 => 149,  440 => 148,  437 => 221,  435 => 146,  430 => 144,  427 => 143,  423 => 142,  413 => 134,  409 => 132,  407 => 131,  402 => 130,  398 => 129,  393 => 126,  387 => 122,  384 => 121,  381 => 120,  379 => 119,  374 => 116,  368 => 112,  365 => 111,  362 => 110,  360 => 109,  355 => 106,  341 => 105,  337 => 103,  322 => 227,  314 => 99,  312 => 98,  309 => 97,  305 => 95,  298 => 91,  294 => 90,  285 => 89,  283 => 88,  278 => 86,  268 => 85,  264 => 84,  258 => 81,  252 => 80,  247 => 78,  241 => 150,  229 => 73,  220 => 111,  214 => 178,  177 => 86,  169 => 123,  140 => 55,  132 => 51,  128 => 49,  111 => 37,  107 => 38,  61 => 24,  273 => 96,  269 => 41,  254 => 92,  246 => 90,  243 => 88,  240 => 86,  238 => 85,  235 => 74,  230 => 82,  227 => 81,  224 => 71,  221 => 77,  219 => 76,  217 => 75,  208 => 68,  204 => 72,  179 => 69,  159 => 61,  143 => 56,  135 => 53,  131 => 52,  119 => 42,  108 => 54,  102 => 68,  71 => 23,  67 => 15,  63 => 33,  59 => 14,  47 => 14,  38 => 9,  94 => 61,  89 => 55,  85 => 38,  79 => 27,  75 => 30,  68 => 22,  56 => 16,  50 => 15,  29 => 6,  87 => 25,  72 => 25,  55 => 16,  21 => 2,  26 => 6,  98 => 31,  93 => 28,  88 => 35,  78 => 21,  46 => 7,  27 => 7,  40 => 8,  44 => 16,  35 => 8,  31 => 7,  43 => 8,  41 => 15,  28 => 3,  201 => 168,  196 => 90,  183 => 82,  171 => 61,  166 => 137,  163 => 118,  158 => 131,  156 => 66,  151 => 63,  142 => 59,  138 => 54,  136 => 56,  123 => 47,  121 => 46,  117 => 90,  115 => 43,  105 => 40,  101 => 32,  91 => 38,  69 => 25,  66 => 15,  62 => 23,  49 => 19,  24 => 4,  32 => 9,  25 => 5,  22 => 1,  19 => 1,  209 => 82,  203 => 169,  199 => 67,  193 => 73,  189 => 71,  187 => 84,  182 => 100,  176 => 64,  173 => 85,  168 => 72,  164 => 59,  162 => 59,  154 => 58,  149 => 75,  147 => 58,  144 => 49,  141 => 70,  133 => 55,  130 => 41,  125 => 44,  122 => 43,  116 => 41,  112 => 55,  109 => 34,  106 => 49,  103 => 32,  99 => 67,  95 => 28,  92 => 21,  86 => 28,  82 => 34,  80 => 19,  73 => 19,  64 => 22,  60 => 13,  57 => 17,  54 => 10,  51 => 16,  48 => 13,  45 => 12,  42 => 11,  39 => 10,  36 => 11,  33 => 8,  30 => 4,);
    }
}
