<?php

/* AppSiteBundle:Default:productos.html.twig */
class __TwigTemplate_91e9b1edf767ba5121ae7504174f756bef98e8f8379b510643d256bb14492c1a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "
<div class=\"items\">
  <div class=\"container\">
    <div class=\"row\">
      <div class=\"col-md-12\">
      <h3 class=\"title\">Productos disponibles</h3>
      </div>
      <!-- Item #1 -->
      <div class=\"col-md-3 col-sm-4\">
        <div class=\"item\">
          <!-- Item image -->
          <div class=\"item-image\">
            <a href=\"single-item.html\">
             ";
        // line 14
        if (isset($context['assetic']['debug']) && $context['assetic']['debug']) {
            // asset "541cb9d_0"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_541cb9d_0") : $this->env->getExtension('assets')->getAssetUrl("images/541cb9d_2_1.png");
            // line 15
            echo "             <img src=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : null), "html", null, true);
            echo "\" alt=\"Example\" />
             ";
        } else {
            // asset "541cb9d"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_541cb9d") : $this->env->getExtension('assets')->getAssetUrl("images/541cb9d.png");
            echo "             <img src=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : null), "html", null, true);
            echo "\" alt=\"Example\" />
             ";
        }
        unset($context["asset_url"]);
        // line 17
        echo "           </a>
         </div>
         <!-- Item details -->
         <div class=\"item-details\">
          <!-- Name -->
          <!-- Use the span tag with the class \"ico\" and icon link (hot, sale, deal, new) -->
          <h5><a href=\"single-item.html\">HTC One V</a><span class=\"ico\">
            ";
        // line 24
        if (isset($context['assetic']['debug']) && $context['assetic']['debug']) {
            // asset "f5bbb76_0"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_f5bbb76_0") : $this->env->getExtension('assets')->getAssetUrl("images/f5bbb76_hot_1.png");
            // line 25
            echo "            <img src=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : null), "html", null, true);
            echo "\" alt=\"Example\" />
            ";
        } else {
            // asset "f5bbb76"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_f5bbb76") : $this->env->getExtension('assets')->getAssetUrl("images/f5bbb76.png");
            echo "            <img src=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : null), "html", null, true);
            echo "\" alt=\"Example\" />
            ";
        }
        unset($context["asset_url"]);
        // line 27
        echo "
          </span></h5>
          <div class=\"clearfix\"></div>
          <!-- Para. Note more than 2 lines. -->
          <p>Something about the product goes here. Not More than 2 lines.</p>
          <hr />
          <!-- Price -->
          <div class=\"item-price pull-left\">\$360</div>
          <!-- Add to cart -->
          <div class=\"button pull-right\"><a href=\"#\">Add to Cart</a></div>
          <div class=\"clearfix\"></div>
        </div>
      </div>
    </div>

    <!-- Item #2 -->
    <div class=\"col-md-3 col-sm-4\">
      <div class=\"item\">
        <!-- Item image -->
        <div class=\"item-image\">
          <a href=\"single-item.html\">
           ";
        // line 48
        if (isset($context['assetic']['debug']) && $context['assetic']['debug']) {
            // asset "3f78a7a_0"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_3f78a7a_0") : $this->env->getExtension('assets')->getAssetUrl("images/3f78a7a_3_1.png");
            // line 49
            echo "           <img src=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : null), "html", null, true);
            echo "\" alt=\"Example\" />
           ";
        } else {
            // asset "3f78a7a"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_3f78a7a") : $this->env->getExtension('assets')->getAssetUrl("images/3f78a7a.png");
            echo "           <img src=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : null), "html", null, true);
            echo "\" alt=\"Example\" />
           ";
        }
        unset($context["asset_url"]);
        // line 51
        echo "         </a>
       </div>
       <!-- Item details -->
       <div class=\"item-details\">
        <!-- Name -->
        <h5><a href=\"single-item.html\">Dell One V</a></h5>
        <!-- Para. Note more than 2 lines. -->
        <p>Something about the product goes here. Not More than 2 lines.</p>
        <hr />
        <!-- Price -->
        <div class=\"item-price pull-left\">\$264</div>
        <!-- Add to cart -->
        <div class=\"button pull-right\"><a href=\"#\">Add to Cart</a></div>
        <div class=\"clearfix\"></div>
      </div>
    </div>
  </div>  

  <div class=\"col-md-3 col-sm-4\">
    <div class=\"item\">
      <!-- Item image -->
      <div class=\"item-image\">
        <a href=\"single-item.html\">
         ";
        // line 74
        if (isset($context['assetic']['debug']) && $context['assetic']['debug']) {
            // asset "280eebf_0"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_280eebf_0") : $this->env->getExtension('assets')->getAssetUrl("images/280eebf_4_1.png");
            // line 75
            echo "         <img src=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : null), "html", null, true);
            echo "\" alt=\"Example\" />
         ";
        } else {
            // asset "280eebf"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_280eebf") : $this->env->getExtension('assets')->getAssetUrl("images/280eebf.png");
            echo "         <img src=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : null), "html", null, true);
            echo "\" alt=\"Example\" />
         ";
        }
        unset($context["asset_url"]);
        // line 77
        echo "       </a>
     </div>
     <!-- Item details -->
     <div class=\"item-details\">
      <!-- Name -->
      <h5><a href=\"single-item.html\">Cannon One V</a><span class=\"ico\">


        ";
        // line 85
        if (isset($context['assetic']['debug']) && $context['assetic']['debug']) {
            // asset "10dcd46_0"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_10dcd46_0") : $this->env->getExtension('assets')->getAssetUrl("images/10dcd46_new_1.png");
            // line 86
            echo "        <img src=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : null), "html", null, true);
            echo "\" alt=\"Example\" />
        ";
        } else {
            // asset "10dcd46"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_10dcd46") : $this->env->getExtension('assets')->getAssetUrl("images/10dcd46.png");
            echo "        <img src=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : null), "html", null, true);
            echo "\" alt=\"Example\" />
        ";
        }
        unset($context["asset_url"]);
        // line 87
        echo "</a>


      </span></h5>
      <!-- Para. Note more than 2 lines. -->
      <p>Something about the product goes here. Not More than 2 lines.</p>
      <hr />
      <!-- Price -->
      <div class=\"item-price pull-left\">\$160</div>
      <!-- Add to cart -->
      <div class=\"button pull-right\"><a href=\"#\">Add to Cart</a></div>
      <div class=\"clearfix\"></div>
    </div>
  </div>
</div>



<div class=\"col-md-3 col-sm-4\">
  <div class=\"item\">
    <!-- Item image -->
    <div class=\"item-image\">
      <a href=\"single-item.html\">
       ";
        // line 110
        if (isset($context['assetic']['debug']) && $context['assetic']['debug']) {
            // asset "40fc194_0"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_40fc194_0") : $this->env->getExtension('assets')->getAssetUrl("images/40fc194_5_1.png");
            // line 111
            echo "       <img src=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : null), "html", null, true);
            echo "\" alt=\"Example\" />
       ";
        } else {
            // asset "40fc194"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_40fc194") : $this->env->getExtension('assets')->getAssetUrl("images/40fc194.png");
            echo "       <img src=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : null), "html", null, true);
            echo "\" alt=\"Example\" />
       ";
        }
        unset($context["asset_url"]);
        // line 113
        echo "     </a>
   </div>
   <!-- Item details -->
   <div class=\"item-details\">
    <!-- Name -->
    <h5><a href=\"single-item.html\">Apple One V</a><span class=\"ico\">


      ";
        // line 121
        if (isset($context['assetic']['debug']) && $context['assetic']['debug']) {
            // asset "5ff6ed1_0"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_5ff6ed1_0") : $this->env->getExtension('assets')->getAssetUrl("images/5ff6ed1_deal_1.png");
            // line 122
            echo "      <img src=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : null), "html", null, true);
            echo "\" alt=\"Example\" />
      ";
        } else {
            // asset "5ff6ed1"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_5ff6ed1") : $this->env->getExtension('assets')->getAssetUrl("images/5ff6ed1.png");
            echo "      <img src=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : null), "html", null, true);
            echo "\" alt=\"Example\" />
      ";
        }
        unset($context["asset_url"]);
        // line 123
        echo "</a>


    </span></h5>
    <!-- Para. Note more than 2 lines. -->
    <p>Something about the product goes here. Not More than 2 lines.</p>
    <hr />
    <!-- Price -->
    <div class=\"item-price pull-left\">\$420</div>
    <!-- Add to cart -->
    <div class=\"button pull-right\"><a href=\"#\">Add to Cart</a></div>
    <div class=\"clearfix\"></div>
  </div>
</div>
</div>

<div class=\"col-md-3 col-sm-4\">
  <div class=\"item\">
    <!-- Item image -->
    <div class=\"item-image\">
     ";
        // line 143
        if (isset($context['assetic']['debug']) && $context['assetic']['debug']) {
            // asset "2b74d30_0"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_2b74d30_0") : $this->env->getExtension('assets')->getAssetUrl("images/2b74d30_6_1.png");
            // line 144
            echo "     <img src=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : null), "html", null, true);
            echo "\" alt=\"Example\" />
     ";
        } else {
            // asset "2b74d30"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_2b74d30") : $this->env->getExtension('assets')->getAssetUrl("images/2b74d30.png");
            echo "     <img src=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : null), "html", null, true);
            echo "\" alt=\"Example\" />
     ";
        }
        unset($context["asset_url"]);
        // line 145
        echo "</a>
   </div>
   <!-- Item details -->
   <div class=\"item-details\">
    <!-- Name -->
    <h5><a href=\"single-item.html\">Samsung One V</a></h5>
    <!-- Para. Note more than 2 lines. -->
    <p>Something about the product goes here. Not More than 2 lines.</p>
    <hr />
    <!-- Price -->
    <div class=\"item-price pull-left\">\$300</div>
    <!-- Add to cart -->
    <div class=\"button pull-right\"><a href=\"#\">Add to Cart</a></div>
    <div class=\"clearfix\"></div>
  </div>
</div>
</div>

<div class=\"col-md-3 col-sm-4\">
  <div class=\"item\">
    <!-- Item image -->
    <div class=\"item-image\">
      <a href=\"single-item.html\">     ";
        // line 167
        if (isset($context['assetic']['debug']) && $context['assetic']['debug']) {
            // asset "6c3190b_0"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_6c3190b_0") : $this->env->getExtension('assets')->getAssetUrl("images/6c3190b_7_1.png");
            // line 168
            echo "        <img src=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : null), "html", null, true);
            echo "\" alt=\"Example\" />
        ";
        } else {
            // asset "6c3190b"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_6c3190b") : $this->env->getExtension('assets')->getAssetUrl("images/6c3190b.png");
            echo "        <img src=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : null), "html", null, true);
            echo "\" alt=\"Example\" />
        ";
        }
        unset($context["asset_url"]);
        // line 169
        echo "</a>
      </div>
      <!-- Item details -->
      <div class=\"item-details\">
        <!-- Name -->
        <h5><a href=\"single-item.html\">Micromax One V</a><span class=\"ico\">
          ";
        // line 175
        if (isset($context['assetic']['debug']) && $context['assetic']['debug']) {
            // asset "9f49248_0"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_9f49248_0") : $this->env->getExtension('assets')->getAssetUrl("images/9f49248_sale_1.png");
            // line 176
            echo "          <img src=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : null), "html", null, true);
            echo "\" alt=\"Example\" />
          ";
        } else {
            // asset "9f49248"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_9f49248") : $this->env->getExtension('assets')->getAssetUrl("images/9f49248.png");
            echo "          <img src=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : null), "html", null, true);
            echo "\" alt=\"Example\" />
          ";
        }
        unset($context["asset_url"]);
        // line 177
        echo "</a>
        </span></h5>
        <!-- Para. Note more than 2 lines. -->
        <p>Something about the product goes here. Not More than 2 lines.</p>
        <hr />
        <!-- Price -->
        <div class=\"item-price pull-left\">\$240</div>
        <!-- Add to cart -->
        <div class=\"button pull-right\"><a href=\"#\">Add to Cart</a></div>
        <div class=\"clearfix\"></div>
      </div>
    </div>
  </div>

  <div class=\"col-md-3 col-sm-4\">
    <div class=\"item\">
      <!-- Item image -->
      <div class=\"item-image\">
        <a href=\"single-item.html\">";
        // line 195
        if (isset($context['assetic']['debug']) && $context['assetic']['debug']) {
            // asset "bc8a856_0"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_bc8a856_0") : $this->env->getExtension('assets')->getAssetUrl("images/bc8a856_8_1.png");
            // line 196
            echo "          <img src=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : null), "html", null, true);
            echo "\" alt=\"Example\" />
          ";
        } else {
            // asset "bc8a856"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_bc8a856") : $this->env->getExtension('assets')->getAssetUrl("images/bc8a856.png");
            echo "          <img src=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : null), "html", null, true);
            echo "\" alt=\"Example\" />
          ";
        }
        unset($context["asset_url"]);
        // line 197
        echo "</a>
        </div>
        <!-- Item details -->
        <div class=\"item-details\">
          <!-- Name -->
          <h5><a href=\"single-item.html\">Nokia One V</a></h5>
          <!-- Para. Note more than 2 lines. -->
          <p>Something about the product goes here. Not More than 2 lines.</p>
          <hr />
          <!-- Price -->
          <div class=\"item-price pull-left\">\$50</div>
          <!-- Add to cart -->
          <div class=\"button pull-right\"><a href=\"#\">Add to Cart</a></div>
          <div class=\"clearfix\"></div>
        </div>
      </div>
    </div>

    <div class=\"col-md-3 col-sm-4\">
      <div class=\"item\">
        <!-- Item image -->
        <div class=\"item-image\">
          <a href=\"single-item.html\">     
            ";
        // line 220
        if (isset($context['assetic']['debug']) && $context['assetic']['debug']) {
            // asset "18bb559_0"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_18bb559_0") : $this->env->getExtension('assets')->getAssetUrl("images/18bb559_9_1.png");
            // line 221
            echo "            <img src=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : null), "html", null, true);
            echo "\" alt=\"Example\" />
            ";
        } else {
            // asset "18bb559"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_18bb559") : $this->env->getExtension('assets')->getAssetUrl("images/18bb559.png");
            echo "            <img src=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : null), "html", null, true);
            echo "\" alt=\"Example\" />
            ";
        }
        unset($context["asset_url"]);
        // line 222
        echo "</a>
          </div>
          <!-- Item details -->
          <div class=\"item-details\">
            <!-- Name -->
            <h5><a href=\"single-item.html\">Sony One V</a></h5>
            <!-- Para. Note more than 2 lines. -->
            <p>Something about the product goes here. Not More than 2 lines.</p>
            <hr />
            <!-- Price -->
            <div class=\"item-price pull-left\">\$100</div>
            <!-- Add to cart -->
            <div class=\"button pull-right\"><a href=\"#\">Add to Cart</a></div>
            <div class=\"clearfix\"></div>
          </div>
        </div>
      </div>                                                                      

    </div>
  </div>
</div>
";
    }

    public function getTemplateName()
    {
        return "AppSiteBundle:Default:productos.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  451 => 222,  433 => 220,  408 => 197,  394 => 196,  390 => 195,  370 => 177,  356 => 176,  352 => 175,  344 => 169,  330 => 168,  326 => 167,  302 => 145,  288 => 144,  284 => 143,  262 => 123,  248 => 122,  244 => 121,  234 => 113,  216 => 110,  191 => 87,  145 => 74,  120 => 51,  65 => 25,  52 => 17,  84 => 28,  34 => 14,  480 => 162,  474 => 161,  469 => 158,  461 => 155,  457 => 153,  453 => 151,  444 => 149,  440 => 148,  437 => 221,  435 => 146,  430 => 144,  427 => 143,  423 => 142,  413 => 134,  409 => 132,  407 => 131,  402 => 130,  398 => 129,  393 => 126,  387 => 122,  384 => 121,  381 => 120,  379 => 119,  374 => 116,  368 => 112,  365 => 111,  362 => 110,  360 => 109,  355 => 106,  341 => 105,  337 => 103,  322 => 101,  314 => 99,  312 => 98,  309 => 97,  305 => 95,  298 => 91,  294 => 90,  285 => 89,  283 => 88,  278 => 86,  268 => 85,  264 => 84,  258 => 81,  252 => 80,  247 => 78,  241 => 77,  229 => 73,  220 => 111,  214 => 69,  177 => 86,  169 => 60,  140 => 55,  132 => 51,  128 => 49,  111 => 37,  107 => 36,  61 => 24,  273 => 96,  269 => 94,  254 => 92,  246 => 90,  243 => 88,  240 => 86,  238 => 85,  235 => 74,  230 => 82,  227 => 81,  224 => 71,  221 => 77,  219 => 76,  217 => 75,  208 => 68,  204 => 72,  179 => 69,  159 => 61,  143 => 56,  135 => 53,  131 => 52,  119 => 42,  108 => 36,  102 => 48,  71 => 23,  67 => 15,  63 => 15,  59 => 14,  47 => 9,  38 => 15,  94 => 28,  89 => 20,  85 => 25,  79 => 27,  75 => 17,  68 => 22,  56 => 16,  50 => 12,  29 => 6,  87 => 25,  72 => 16,  55 => 15,  21 => 2,  26 => 6,  98 => 31,  93 => 28,  88 => 6,  78 => 21,  46 => 7,  27 => 7,  40 => 11,  44 => 12,  35 => 5,  31 => 8,  43 => 8,  41 => 7,  28 => 3,  201 => 92,  196 => 90,  183 => 82,  171 => 61,  166 => 71,  163 => 77,  158 => 67,  156 => 66,  151 => 63,  142 => 59,  138 => 54,  136 => 56,  123 => 47,  121 => 46,  117 => 44,  115 => 43,  105 => 40,  101 => 32,  91 => 27,  69 => 25,  66 => 15,  62 => 23,  49 => 19,  24 => 4,  32 => 4,  25 => 5,  22 => 2,  19 => 1,  209 => 82,  203 => 78,  199 => 67,  193 => 73,  189 => 71,  187 => 84,  182 => 66,  176 => 64,  173 => 85,  168 => 72,  164 => 59,  162 => 59,  154 => 58,  149 => 75,  147 => 58,  144 => 49,  141 => 48,  133 => 55,  130 => 41,  125 => 44,  122 => 43,  116 => 41,  112 => 42,  109 => 34,  106 => 49,  103 => 32,  99 => 31,  95 => 28,  92 => 21,  86 => 28,  82 => 22,  80 => 19,  73 => 19,  64 => 21,  60 => 13,  57 => 11,  54 => 10,  51 => 13,  48 => 13,  45 => 9,  42 => 7,  39 => 9,  36 => 10,  33 => 4,  30 => 7,);
    }
}
