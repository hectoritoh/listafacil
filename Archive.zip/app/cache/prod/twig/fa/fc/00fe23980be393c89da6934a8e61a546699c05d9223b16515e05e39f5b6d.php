<?php

/* SonataBlockBundle:Block:block_template.html.twig */
class __TwigTemplate_fafc00fe23980be393c89da6934a8e61a546699c05d9223b16515e05e39f5b6d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->blocks = array(
            'block' => array($this, 'block_block'),
        );
    }

    protected function doGetParent(array $context)
    {
        return $this->env->resolveTemplate($this->getAttribute($this->getAttribute((isset($context["sonata_block"]) ? $context["sonata_block"] : null), "templates"), "block_base"));
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->getParent($context)->display($context, array_merge($this->blocks, $blocks));
    }

    // line 14
    public function block_block($context, array $blocks = array())
    {
        // line 15
        echo "    <h3>Sonata Block Template</h3>
    If you want to use the <code>sonata.block.template</code> block type, you need to create a template :

    <pre>";
        // line 33
        echo "{# file: 'MyBundle:Block:my_block_feature_1.html.twig' #}
{% extends sonata_block.templates.block_base %}

{% block block %}
    &lt;h3&gt;The block title&lt;/h3&gt;
    &lt;p&gt;
        Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam vel turpis at lacus
        vehicula fringilla at eu lectus. Duis vitae arcu congue, porttitor nisi sit amet,
        mattis metus. Nunc mollis elit ut lectus cursus luctus. Aliquam eu magna sit amet
        massa volutpat auctor.
    &lt;/p&gt;
{% endblock %}";
        echo "</pre>

    And then call it from a template with the <code>sonata_block_render</code> helper:

    <pre>";
        // line 43
        echo "{{ sonata_block_render({ 'type': 'sonata.block.service.template' }, {
    'template': 'MyBundle:Block:my_block_feature_1.html.twig',
}) }}";
        echo "</pre>
";
    }

    public function getTemplateName()
    {
        return "SonataBlockBundle:Block:block_template.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  270 => 4,  253 => 1,  233 => 81,  212 => 74,  210 => 73,  206 => 71,  202 => 68,  198 => 66,  192 => 64,  185 => 59,  167 => 48,  137 => 37,  113 => 31,  129 => 59,  97 => 47,  77 => 36,  20 => 11,  58 => 22,  23 => 27,  325 => 228,  292 => 197,  290 => 196,  237 => 149,  165 => 47,  100 => 23,  53 => 23,  160 => 44,  152 => 111,  175 => 53,  172 => 51,  155 => 112,  327 => 155,  324 => 154,  319 => 149,  316 => 148,  279 => 49,  266 => 40,  256 => 188,  218 => 186,  188 => 157,  186 => 101,  180 => 56,  178 => 148,  81 => 15,  74 => 11,  126 => 57,  90 => 20,  76 => 36,  37 => 19,  451 => 222,  433 => 220,  408 => 197,  394 => 196,  390 => 195,  370 => 177,  356 => 176,  352 => 175,  344 => 169,  330 => 168,  326 => 167,  302 => 145,  288 => 144,  284 => 143,  262 => 123,  248 => 122,  244 => 121,  234 => 113,  216 => 110,  191 => 87,  145 => 71,  120 => 36,  65 => 83,  52 => 43,  84 => 16,  34 => 33,  480 => 162,  474 => 161,  469 => 158,  461 => 155,  457 => 153,  453 => 151,  444 => 149,  440 => 148,  437 => 221,  435 => 146,  430 => 144,  427 => 143,  423 => 142,  413 => 134,  409 => 132,  407 => 131,  402 => 130,  398 => 129,  393 => 126,  387 => 122,  384 => 121,  381 => 120,  379 => 119,  374 => 116,  368 => 112,  365 => 111,  362 => 110,  360 => 109,  355 => 106,  341 => 105,  337 => 103,  322 => 227,  314 => 99,  312 => 98,  309 => 97,  305 => 95,  298 => 91,  294 => 90,  285 => 89,  283 => 88,  278 => 86,  268 => 3,  264 => 2,  258 => 81,  252 => 80,  247 => 78,  241 => 150,  229 => 73,  220 => 111,  214 => 178,  177 => 54,  169 => 49,  140 => 55,  132 => 51,  128 => 49,  111 => 30,  107 => 52,  61 => 24,  273 => 96,  269 => 41,  254 => 92,  246 => 90,  243 => 83,  240 => 86,  238 => 85,  235 => 74,  230 => 82,  227 => 81,  224 => 71,  221 => 79,  219 => 76,  217 => 75,  208 => 72,  204 => 72,  179 => 69,  159 => 61,  143 => 56,  135 => 53,  131 => 52,  119 => 42,  108 => 28,  102 => 68,  71 => 23,  67 => 25,  63 => 33,  59 => 14,  47 => 43,  38 => 9,  94 => 39,  89 => 43,  85 => 38,  79 => 37,  75 => 30,  68 => 22,  56 => 23,  50 => 44,  29 => 15,  87 => 25,  72 => 10,  55 => 79,  21 => 11,  26 => 14,  98 => 24,  93 => 21,  88 => 35,  78 => 31,  46 => 7,  27 => 8,  40 => 20,  44 => 18,  35 => 15,  31 => 14,  43 => 8,  41 => 18,  28 => 44,  201 => 168,  196 => 65,  183 => 82,  171 => 61,  166 => 137,  163 => 45,  158 => 131,  156 => 41,  151 => 63,  142 => 59,  138 => 54,  136 => 56,  123 => 47,  121 => 46,  117 => 34,  115 => 33,  105 => 51,  101 => 49,  91 => 44,  69 => 9,  66 => 29,  62 => 82,  49 => 19,  24 => 4,  32 => 14,  25 => 12,  22 => 1,  19 => 11,  209 => 82,  203 => 169,  199 => 67,  193 => 73,  189 => 61,  187 => 60,  182 => 57,  176 => 64,  173 => 85,  168 => 72,  164 => 59,  162 => 59,  154 => 40,  149 => 75,  147 => 58,  144 => 49,  141 => 70,  133 => 55,  130 => 41,  125 => 44,  122 => 43,  116 => 41,  112 => 55,  109 => 53,  106 => 49,  103 => 50,  99 => 67,  95 => 22,  92 => 21,  86 => 17,  82 => 39,  80 => 19,  73 => 19,  64 => 28,  60 => 81,  57 => 80,  54 => 10,  51 => 22,  48 => 21,  45 => 28,  42 => 27,  39 => 17,  36 => 16,  33 => 11,  30 => 9,);
    }
}
