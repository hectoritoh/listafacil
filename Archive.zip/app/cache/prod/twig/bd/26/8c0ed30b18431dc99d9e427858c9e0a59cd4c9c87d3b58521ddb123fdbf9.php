<?php

/* SonataCoreBundle:FlashMessage:render.html.twig */
class __TwigTemplate_bd268c0ed30b18431dc99d9e427858c9e0a59cd4c9c87d3b58521ddb123fdbf9 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 11
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable($this->env->getExtension('sonata_core_flashmessage')->getFlashMessagesTypes());
        foreach ($context['_seq'] as $context["_key"] => $context["type"]) {
            // line 12
            echo "    ";
            $context["domain"] = ((array_key_exists("domain", $context)) ? ((isset($context["domain"]) ? $context["domain"] : null)) : (null));
            // line 13
            echo "    ";
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable($this->env->getExtension('sonata_core_flashmessage')->getFlashMessages((isset($context["type"]) ? $context["type"] : null), (isset($context["domain"]) ? $context["domain"] : null)));
            foreach ($context['_seq'] as $context["_key"] => $context["message"]) {
                // line 14
                echo "        <div class=\"alert alert-";
                echo twig_escape_filter($this->env, $this->env->getExtension('sonata_core_status')->statusClass((isset($context["type"]) ? $context["type"] : null)), "html", null, true);
                echo " alert-dismissable\">
            <button type=\"button\" class=\"close\" data-dismiss=\"alert\" aria-hidden=\"true\">&times;</button>
            ";
                // line 16
                echo (isset($context["message"]) ? $context["message"] : null);
                echo "
        </div>
    ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['message'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['type'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
    }

    public function getTemplateName()
    {
        return "SonataCoreBundle:FlashMessage:render.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  23 => 12,  325 => 228,  292 => 197,  290 => 196,  237 => 149,  165 => 88,  100 => 45,  53 => 16,  160 => 117,  152 => 111,  175 => 143,  172 => 124,  155 => 112,  327 => 155,  324 => 154,  319 => 149,  316 => 148,  279 => 49,  266 => 40,  256 => 188,  218 => 186,  188 => 157,  186 => 101,  180 => 150,  178 => 148,  81 => 49,  74 => 46,  126 => 57,  90 => 28,  76 => 36,  37 => 16,  451 => 222,  433 => 220,  408 => 197,  394 => 196,  390 => 195,  370 => 177,  356 => 176,  352 => 175,  344 => 169,  330 => 168,  326 => 167,  302 => 145,  288 => 144,  284 => 143,  262 => 123,  248 => 122,  244 => 121,  234 => 113,  216 => 110,  191 => 87,  145 => 71,  120 => 51,  65 => 25,  52 => 17,  84 => 28,  34 => 4,  480 => 162,  474 => 161,  469 => 158,  461 => 155,  457 => 153,  453 => 151,  444 => 149,  440 => 148,  437 => 221,  435 => 146,  430 => 144,  427 => 143,  423 => 142,  413 => 134,  409 => 132,  407 => 131,  402 => 130,  398 => 129,  393 => 126,  387 => 122,  384 => 121,  381 => 120,  379 => 119,  374 => 116,  368 => 112,  365 => 111,  362 => 110,  360 => 109,  355 => 106,  341 => 105,  337 => 103,  322 => 227,  314 => 99,  312 => 98,  309 => 97,  305 => 95,  298 => 91,  294 => 90,  285 => 89,  283 => 88,  278 => 86,  268 => 85,  264 => 84,  258 => 81,  252 => 80,  247 => 78,  241 => 150,  229 => 73,  220 => 111,  214 => 178,  177 => 86,  169 => 123,  140 => 55,  132 => 51,  128 => 49,  111 => 37,  107 => 38,  61 => 24,  273 => 96,  269 => 41,  254 => 92,  246 => 90,  243 => 88,  240 => 86,  238 => 85,  235 => 74,  230 => 82,  227 => 81,  224 => 71,  221 => 77,  219 => 76,  217 => 75,  208 => 68,  204 => 72,  179 => 69,  159 => 61,  143 => 56,  135 => 53,  131 => 52,  119 => 42,  108 => 54,  102 => 68,  71 => 23,  67 => 15,  63 => 33,  59 => 14,  47 => 14,  38 => 9,  94 => 61,  89 => 55,  85 => 38,  79 => 27,  75 => 30,  68 => 22,  56 => 16,  50 => 15,  29 => 6,  87 => 25,  72 => 25,  55 => 16,  21 => 2,  26 => 13,  98 => 31,  93 => 28,  88 => 35,  78 => 21,  46 => 7,  27 => 7,  40 => 8,  44 => 16,  35 => 8,  31 => 14,  43 => 8,  41 => 15,  28 => 3,  201 => 168,  196 => 90,  183 => 82,  171 => 61,  166 => 137,  163 => 118,  158 => 131,  156 => 66,  151 => 63,  142 => 59,  138 => 54,  136 => 56,  123 => 47,  121 => 46,  117 => 90,  115 => 43,  105 => 40,  101 => 32,  91 => 38,  69 => 25,  66 => 15,  62 => 23,  49 => 19,  24 => 4,  32 => 9,  25 => 5,  22 => 1,  19 => 11,  209 => 82,  203 => 169,  199 => 67,  193 => 73,  189 => 71,  187 => 84,  182 => 100,  176 => 64,  173 => 85,  168 => 72,  164 => 59,  162 => 59,  154 => 58,  149 => 75,  147 => 58,  144 => 49,  141 => 70,  133 => 55,  130 => 41,  125 => 44,  122 => 43,  116 => 41,  112 => 55,  109 => 34,  106 => 49,  103 => 32,  99 => 67,  95 => 28,  92 => 21,  86 => 28,  82 => 34,  80 => 19,  73 => 19,  64 => 22,  60 => 13,  57 => 17,  54 => 10,  51 => 16,  48 => 13,  45 => 12,  42 => 11,  39 => 10,  36 => 11,  33 => 8,  30 => 4,);
    }
}
