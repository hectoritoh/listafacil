<?php

use Symfony\Component\Routing\Exception\MethodNotAllowedException;
use Symfony\Component\Routing\Exception\ResourceNotFoundException;
use Symfony\Component\Routing\RequestContext;

/**
 * appProdUrlMatcher
 *
 * This class has been auto-generated
 * by the Symfony Routing Component.
 */
class appProdUrlMatcher extends Symfony\Bundle\FrameworkBundle\Routing\RedirectableUrlMatcher
{
    /**
     * Constructor.
     */
    public function __construct(RequestContext $context)
    {
        $this->context = $context;
    }

    public function match($pathinfo)
    {
        $allow = array();
        $pathinfo = rawurldecode($pathinfo);
        $context = $this->context;
        $request = $this->request;

        // home
        if (rtrim($pathinfo, '/') === '') {
            if (substr($pathinfo, -1) !== '/') {
                return $this->redirect($pathinfo.'/', 'home');
            }

            return array (  '_controller' => 'App\\SiteBundle\\Controller\\DefaultController::indexAction',  '_route' => 'home',);
        }

        // quienes_somos
        if ($pathinfo === '/nosotros') {
            return array (  '_controller' => 'App\\SiteBundle\\Controller\\DefaultController::nosotrosAction',  '_route' => 'quienes_somos',);
        }

        // ver_producto
        if (0 === strpos($pathinfo, '/producto') && preg_match('#^/producto/(?P<slug>[^/]++)$#s', $pathinfo, $matches)) {
            return $this->mergeDefaults(array_replace($matches, array('_route' => 'ver_producto')), array (  '_controller' => 'App\\SiteBundle\\Controller\\DefaultController::productoAction',));
        }

        if (0 === strpos($pathinfo, '/c')) {
            // ver_categoria
            if (0 === strpos($pathinfo, '/categoria') && preg_match('#^/categoria/(?P<slug>[^/]++)$#s', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, array('_route' => 'ver_categoria')), array (  '_controller' => 'App\\SiteBundle\\Controller\\DefaultController::categoriaAction',));
            }

            if (0 === strpos($pathinfo, '/co')) {
                // contactenos
                if ($pathinfo === '/contactenos') {
                    return array (  '_controller' => 'App\\SiteBundle\\Controller\\DefaultController::contactenosAction',  '_route' => 'contactenos',);
                }

                // comentar
                if ($pathinfo === '/comentar') {
                    return array (  '_controller' => 'App\\SiteBundle\\Controller\\DefaultController::comentarAction',  '_route' => 'comentar',);
                }

            }

        }

        // help
        if ($pathinfo === '/generar_slug') {
            return array (  '_controller' => 'App\\SiteBundle\\Controller\\DefaultController::generar_slugAction',  '_route' => 'help',);
        }

        // register
        if ($pathinfo === '/registrar') {
            return array (  '_controller' => 'App\\SiteBundle\\Controller\\SecurityController::registerAction',  '_route' => 'register',);
        }

        if (0 === strpos($pathinfo, '/log')) {
            if (0 === strpos($pathinfo, '/login')) {
                // login
                if ($pathinfo === '/login') {
                    return array (  '_controller' => 'App\\SiteBundle\\Controller\\SecurityController::loginAction',  '_route' => 'login',);
                }

                // login_check
                if ($pathinfo === '/login_check') {
                    return array('_route' => 'login_check');
                }

            }

            // logout
            if ($pathinfo === '/logout') {
                return array('_route' => 'logout');
            }

        }

        // app_tienda_online_homepage
        if (0 === strpos($pathinfo, '/hello') && preg_match('#^/hello/(?P<name>[^/]++)$#s', $pathinfo, $matches)) {
            return $this->mergeDefaults(array_replace($matches, array('_route' => 'app_tienda_online_homepage')), array (  '_controller' => 'App\\TiendaOnlineBundle\\Controller\\DefaultController::indexAction',));
        }

        if (0 === strpos($pathinfo, '/admin')) {
            // sonata_admin_redirect
            if (rtrim($pathinfo, '/') === '/admin') {
                if (substr($pathinfo, -1) !== '/') {
                    return $this->redirect($pathinfo.'/', 'sonata_admin_redirect');
                }

                return array (  '_controller' => 'Symfony\\Bundle\\FrameworkBundle\\Controller\\RedirectController::redirectAction',  'route' => 'sonata_admin_dashboard',  'permanent' => 'true',  '_route' => 'sonata_admin_redirect',);
            }

            // sonata_admin_dashboard
            if ($pathinfo === '/admin/dashboard') {
                return array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CoreController::dashboardAction',  '_route' => 'sonata_admin_dashboard',);
            }

            if (0 === strpos($pathinfo, '/admin/core')) {
                // sonata_admin_retrieve_form_element
                if ($pathinfo === '/admin/core/get-form-field-element') {
                    return array (  '_controller' => 'sonata.admin.controller.admin:retrieveFormFieldElementAction',  '_route' => 'sonata_admin_retrieve_form_element',);
                }

                // sonata_admin_append_form_element
                if ($pathinfo === '/admin/core/append-form-field-element') {
                    return array (  '_controller' => 'sonata.admin.controller.admin:appendFormFieldElementAction',  '_route' => 'sonata_admin_append_form_element',);
                }

                // sonata_admin_short_object_information
                if (0 === strpos($pathinfo, '/admin/core/get-short-object-description') && preg_match('#^/admin/core/get\\-short\\-object\\-description(?:\\.(?P<_format>html|json))?$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'sonata_admin_short_object_information')), array (  '_controller' => 'sonata.admin.controller.admin:getShortObjectDescriptionAction',  '_format' => 'html',));
                }

                // sonata_admin_set_object_field_value
                if ($pathinfo === '/admin/core/set-object-field-value') {
                    return array (  '_controller' => 'sonata.admin.controller.admin:setObjectFieldValueAction',  '_route' => 'sonata_admin_set_object_field_value',);
                }

            }

            // sonata_admin_search
            if ($pathinfo === '/admin/search') {
                return array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CoreController::searchAction',  '_route' => 'sonata_admin_search',);
            }

            if (0 === strpos($pathinfo, '/admin/app/tiendaonline')) {
                if (0 === strpos($pathinfo, '/admin/app/tiendaonline/c')) {
                    if (0 === strpos($pathinfo, '/admin/app/tiendaonline/contenido')) {
                        // admin_app_tiendaonline_contenido_list
                        if ($pathinfo === '/admin/app/tiendaonline/contenido/list') {
                            return array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::listAction',  '_sonata_admin' => 'sonata.admin.contenido',  '_sonata_name' => 'admin_app_tiendaonline_contenido_list',  '_route' => 'admin_app_tiendaonline_contenido_list',);
                        }

                        // admin_app_tiendaonline_contenido_create
                        if ($pathinfo === '/admin/app/tiendaonline/contenido/create') {
                            return array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::createAction',  '_sonata_admin' => 'sonata.admin.contenido',  '_sonata_name' => 'admin_app_tiendaonline_contenido_create',  '_route' => 'admin_app_tiendaonline_contenido_create',);
                        }

                        // admin_app_tiendaonline_contenido_batch
                        if ($pathinfo === '/admin/app/tiendaonline/contenido/batch') {
                            return array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::batchAction',  '_sonata_admin' => 'sonata.admin.contenido',  '_sonata_name' => 'admin_app_tiendaonline_contenido_batch',  '_route' => 'admin_app_tiendaonline_contenido_batch',);
                        }

                        // admin_app_tiendaonline_contenido_edit
                        if (preg_match('#^/admin/app/tiendaonline/contenido/(?P<id>[^/]++)/edit$#s', $pathinfo, $matches)) {
                            return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_app_tiendaonline_contenido_edit')), array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::editAction',  '_sonata_admin' => 'sonata.admin.contenido',  '_sonata_name' => 'admin_app_tiendaonline_contenido_edit',));
                        }

                        // admin_app_tiendaonline_contenido_delete
                        if (preg_match('#^/admin/app/tiendaonline/contenido/(?P<id>[^/]++)/delete$#s', $pathinfo, $matches)) {
                            return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_app_tiendaonline_contenido_delete')), array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::deleteAction',  '_sonata_admin' => 'sonata.admin.contenido',  '_sonata_name' => 'admin_app_tiendaonline_contenido_delete',));
                        }

                        // admin_app_tiendaonline_contenido_show
                        if (preg_match('#^/admin/app/tiendaonline/contenido/(?P<id>[^/]++)/show$#s', $pathinfo, $matches)) {
                            return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_app_tiendaonline_contenido_show')), array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::showAction',  '_sonata_admin' => 'sonata.admin.contenido',  '_sonata_name' => 'admin_app_tiendaonline_contenido_show',));
                        }

                        // admin_app_tiendaonline_contenido_export
                        if ($pathinfo === '/admin/app/tiendaonline/contenido/export') {
                            return array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::exportAction',  '_sonata_admin' => 'sonata.admin.contenido',  '_sonata_name' => 'admin_app_tiendaonline_contenido_export',  '_route' => 'admin_app_tiendaonline_contenido_export',);
                        }

                    }

                    if (0 === strpos($pathinfo, '/admin/app/tiendaonline/categoria')) {
                        // admin_app_tiendaonline_categoria_list
                        if ($pathinfo === '/admin/app/tiendaonline/categoria/list') {
                            return array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::listAction',  '_sonata_admin' => 'sonata.admin.categoria',  '_sonata_name' => 'admin_app_tiendaonline_categoria_list',  '_route' => 'admin_app_tiendaonline_categoria_list',);
                        }

                        // admin_app_tiendaonline_categoria_create
                        if ($pathinfo === '/admin/app/tiendaonline/categoria/create') {
                            return array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::createAction',  '_sonata_admin' => 'sonata.admin.categoria',  '_sonata_name' => 'admin_app_tiendaonline_categoria_create',  '_route' => 'admin_app_tiendaonline_categoria_create',);
                        }

                        // admin_app_tiendaonline_categoria_batch
                        if ($pathinfo === '/admin/app/tiendaonline/categoria/batch') {
                            return array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::batchAction',  '_sonata_admin' => 'sonata.admin.categoria',  '_sonata_name' => 'admin_app_tiendaonline_categoria_batch',  '_route' => 'admin_app_tiendaonline_categoria_batch',);
                        }

                        // admin_app_tiendaonline_categoria_edit
                        if (preg_match('#^/admin/app/tiendaonline/categoria/(?P<id>[^/]++)/edit$#s', $pathinfo, $matches)) {
                            return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_app_tiendaonline_categoria_edit')), array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::editAction',  '_sonata_admin' => 'sonata.admin.categoria',  '_sonata_name' => 'admin_app_tiendaonline_categoria_edit',));
                        }

                        // admin_app_tiendaonline_categoria_delete
                        if (preg_match('#^/admin/app/tiendaonline/categoria/(?P<id>[^/]++)/delete$#s', $pathinfo, $matches)) {
                            return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_app_tiendaonline_categoria_delete')), array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::deleteAction',  '_sonata_admin' => 'sonata.admin.categoria',  '_sonata_name' => 'admin_app_tiendaonline_categoria_delete',));
                        }

                        // admin_app_tiendaonline_categoria_show
                        if (preg_match('#^/admin/app/tiendaonline/categoria/(?P<id>[^/]++)/show$#s', $pathinfo, $matches)) {
                            return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_app_tiendaonline_categoria_show')), array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::showAction',  '_sonata_admin' => 'sonata.admin.categoria',  '_sonata_name' => 'admin_app_tiendaonline_categoria_show',));
                        }

                        // admin_app_tiendaonline_categoria_export
                        if ($pathinfo === '/admin/app/tiendaonline/categoria/export') {
                            return array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::exportAction',  '_sonata_admin' => 'sonata.admin.categoria',  '_sonata_name' => 'admin_app_tiendaonline_categoria_export',  '_route' => 'admin_app_tiendaonline_categoria_export',);
                        }

                    }

                }

                if (0 === strpos($pathinfo, '/admin/app/tiendaonline/banner')) {
                    // admin_app_tiendaonline_banner_list
                    if ($pathinfo === '/admin/app/tiendaonline/banner/list') {
                        return array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::listAction',  '_sonata_admin' => 'app_tienda_online.admin.banner',  '_sonata_name' => 'admin_app_tiendaonline_banner_list',  '_route' => 'admin_app_tiendaonline_banner_list',);
                    }

                    // admin_app_tiendaonline_banner_create
                    if ($pathinfo === '/admin/app/tiendaonline/banner/create') {
                        return array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::createAction',  '_sonata_admin' => 'app_tienda_online.admin.banner',  '_sonata_name' => 'admin_app_tiendaonline_banner_create',  '_route' => 'admin_app_tiendaonline_banner_create',);
                    }

                    // admin_app_tiendaonline_banner_batch
                    if ($pathinfo === '/admin/app/tiendaonline/banner/batch') {
                        return array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::batchAction',  '_sonata_admin' => 'app_tienda_online.admin.banner',  '_sonata_name' => 'admin_app_tiendaonline_banner_batch',  '_route' => 'admin_app_tiendaonline_banner_batch',);
                    }

                    // admin_app_tiendaonline_banner_edit
                    if (preg_match('#^/admin/app/tiendaonline/banner/(?P<id>[^/]++)/edit$#s', $pathinfo, $matches)) {
                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_app_tiendaonline_banner_edit')), array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::editAction',  '_sonata_admin' => 'app_tienda_online.admin.banner',  '_sonata_name' => 'admin_app_tiendaonline_banner_edit',));
                    }

                    // admin_app_tiendaonline_banner_delete
                    if (preg_match('#^/admin/app/tiendaonline/banner/(?P<id>[^/]++)/delete$#s', $pathinfo, $matches)) {
                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_app_tiendaonline_banner_delete')), array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::deleteAction',  '_sonata_admin' => 'app_tienda_online.admin.banner',  '_sonata_name' => 'admin_app_tiendaonline_banner_delete',));
                    }

                    // admin_app_tiendaonline_banner_show
                    if (preg_match('#^/admin/app/tiendaonline/banner/(?P<id>[^/]++)/show$#s', $pathinfo, $matches)) {
                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_app_tiendaonline_banner_show')), array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::showAction',  '_sonata_admin' => 'app_tienda_online.admin.banner',  '_sonata_name' => 'admin_app_tiendaonline_banner_show',));
                    }

                    // admin_app_tiendaonline_banner_export
                    if ($pathinfo === '/admin/app/tiendaonline/banner/export') {
                        return array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::exportAction',  '_sonata_admin' => 'app_tienda_online.admin.banner',  '_sonata_name' => 'admin_app_tiendaonline_banner_export',  '_route' => 'admin_app_tiendaonline_banner_export',);
                    }

                }

                if (0 === strpos($pathinfo, '/admin/app/tiendaonline/producto')) {
                    // admin_app_tiendaonline_producto_list
                    if ($pathinfo === '/admin/app/tiendaonline/producto/list') {
                        return array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::listAction',  '_sonata_admin' => 'app_tienda_online.admin.producto',  '_sonata_name' => 'admin_app_tiendaonline_producto_list',  '_route' => 'admin_app_tiendaonline_producto_list',);
                    }

                    // admin_app_tiendaonline_producto_create
                    if ($pathinfo === '/admin/app/tiendaonline/producto/create') {
                        return array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::createAction',  '_sonata_admin' => 'app_tienda_online.admin.producto',  '_sonata_name' => 'admin_app_tiendaonline_producto_create',  '_route' => 'admin_app_tiendaonline_producto_create',);
                    }

                    // admin_app_tiendaonline_producto_batch
                    if ($pathinfo === '/admin/app/tiendaonline/producto/batch') {
                        return array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::batchAction',  '_sonata_admin' => 'app_tienda_online.admin.producto',  '_sonata_name' => 'admin_app_tiendaonline_producto_batch',  '_route' => 'admin_app_tiendaonline_producto_batch',);
                    }

                    // admin_app_tiendaonline_producto_edit
                    if (preg_match('#^/admin/app/tiendaonline/producto/(?P<id>[^/]++)/edit$#s', $pathinfo, $matches)) {
                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_app_tiendaonline_producto_edit')), array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::editAction',  '_sonata_admin' => 'app_tienda_online.admin.producto',  '_sonata_name' => 'admin_app_tiendaonline_producto_edit',));
                    }

                    // admin_app_tiendaonline_producto_delete
                    if (preg_match('#^/admin/app/tiendaonline/producto/(?P<id>[^/]++)/delete$#s', $pathinfo, $matches)) {
                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_app_tiendaonline_producto_delete')), array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::deleteAction',  '_sonata_admin' => 'app_tienda_online.admin.producto',  '_sonata_name' => 'admin_app_tiendaonline_producto_delete',));
                    }

                    // admin_app_tiendaonline_producto_show
                    if (preg_match('#^/admin/app/tiendaonline/producto/(?P<id>[^/]++)/show$#s', $pathinfo, $matches)) {
                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_app_tiendaonline_producto_show')), array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::showAction',  '_sonata_admin' => 'app_tienda_online.admin.producto',  '_sonata_name' => 'admin_app_tiendaonline_producto_show',));
                    }

                    // admin_app_tiendaonline_producto_export
                    if ($pathinfo === '/admin/app/tiendaonline/producto/export') {
                        return array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::exportAction',  '_sonata_admin' => 'app_tienda_online.admin.producto',  '_sonata_name' => 'admin_app_tiendaonline_producto_export',  '_route' => 'admin_app_tiendaonline_producto_export',);
                    }

                }

                if (0 === strpos($pathinfo, '/admin/app/tiendaonline/institucion')) {
                    // admin_app_tiendaonline_institucion_list
                    if ($pathinfo === '/admin/app/tiendaonline/institucion/list') {
                        return array (  '_controller' => 'App\\TiendaOnlineBundle\\Controller\\InstitucionAdminController::listAction',  '_sonata_admin' => 'app_tienda_online.admin.institucion',  '_sonata_name' => 'admin_app_tiendaonline_institucion_list',  '_route' => 'admin_app_tiendaonline_institucion_list',);
                    }

                    // admin_app_tiendaonline_institucion_create
                    if ($pathinfo === '/admin/app/tiendaonline/institucion/create') {
                        return array (  '_controller' => 'App\\TiendaOnlineBundle\\Controller\\InstitucionAdminController::createAction',  '_sonata_admin' => 'app_tienda_online.admin.institucion',  '_sonata_name' => 'admin_app_tiendaonline_institucion_create',  '_route' => 'admin_app_tiendaonline_institucion_create',);
                    }

                    // admin_app_tiendaonline_institucion_batch
                    if ($pathinfo === '/admin/app/tiendaonline/institucion/batch') {
                        return array (  '_controller' => 'App\\TiendaOnlineBundle\\Controller\\InstitucionAdminController::batchAction',  '_sonata_admin' => 'app_tienda_online.admin.institucion',  '_sonata_name' => 'admin_app_tiendaonline_institucion_batch',  '_route' => 'admin_app_tiendaonline_institucion_batch',);
                    }

                    // admin_app_tiendaonline_institucion_edit
                    if (preg_match('#^/admin/app/tiendaonline/institucion/(?P<id>[^/]++)/edit$#s', $pathinfo, $matches)) {
                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_app_tiendaonline_institucion_edit')), array (  '_controller' => 'App\\TiendaOnlineBundle\\Controller\\InstitucionAdminController::editAction',  '_sonata_admin' => 'app_tienda_online.admin.institucion',  '_sonata_name' => 'admin_app_tiendaonline_institucion_edit',));
                    }

                    // admin_app_tiendaonline_institucion_delete
                    if (preg_match('#^/admin/app/tiendaonline/institucion/(?P<id>[^/]++)/delete$#s', $pathinfo, $matches)) {
                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_app_tiendaonline_institucion_delete')), array (  '_controller' => 'App\\TiendaOnlineBundle\\Controller\\InstitucionAdminController::deleteAction',  '_sonata_admin' => 'app_tienda_online.admin.institucion',  '_sonata_name' => 'admin_app_tiendaonline_institucion_delete',));
                    }

                    // admin_app_tiendaonline_institucion_show
                    if (preg_match('#^/admin/app/tiendaonline/institucion/(?P<id>[^/]++)/show$#s', $pathinfo, $matches)) {
                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_app_tiendaonline_institucion_show')), array (  '_controller' => 'App\\TiendaOnlineBundle\\Controller\\InstitucionAdminController::showAction',  '_sonata_admin' => 'app_tienda_online.admin.institucion',  '_sonata_name' => 'admin_app_tiendaonline_institucion_show',));
                    }

                    // admin_app_tiendaonline_institucion_export
                    if ($pathinfo === '/admin/app/tiendaonline/institucion/export') {
                        return array (  '_controller' => 'App\\TiendaOnlineBundle\\Controller\\InstitucionAdminController::exportAction',  '_sonata_admin' => 'app_tienda_online.admin.institucion',  '_sonata_name' => 'admin_app_tiendaonline_institucion_export',  '_route' => 'admin_app_tiendaonline_institucion_export',);
                    }

                }

                if (0 === strpos($pathinfo, '/admin/app/tiendaonline/lista')) {
                    // admin_app_tiendaonline_lista_list
                    if ($pathinfo === '/admin/app/tiendaonline/lista/list') {
                        return array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::listAction',  '_sonata_admin' => 'app_tienda_online.admin.lista',  '_sonata_name' => 'admin_app_tiendaonline_lista_list',  '_route' => 'admin_app_tiendaonline_lista_list',);
                    }

                    // admin_app_tiendaonline_lista_create
                    if ($pathinfo === '/admin/app/tiendaonline/lista/create') {
                        return array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::createAction',  '_sonata_admin' => 'app_tienda_online.admin.lista',  '_sonata_name' => 'admin_app_tiendaonline_lista_create',  '_route' => 'admin_app_tiendaonline_lista_create',);
                    }

                    // admin_app_tiendaonline_lista_batch
                    if ($pathinfo === '/admin/app/tiendaonline/lista/batch') {
                        return array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::batchAction',  '_sonata_admin' => 'app_tienda_online.admin.lista',  '_sonata_name' => 'admin_app_tiendaonline_lista_batch',  '_route' => 'admin_app_tiendaonline_lista_batch',);
                    }

                    // admin_app_tiendaonline_lista_edit
                    if (preg_match('#^/admin/app/tiendaonline/lista/(?P<id>[^/]++)/edit$#s', $pathinfo, $matches)) {
                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_app_tiendaonline_lista_edit')), array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::editAction',  '_sonata_admin' => 'app_tienda_online.admin.lista',  '_sonata_name' => 'admin_app_tiendaonline_lista_edit',));
                    }

                    // admin_app_tiendaonline_lista_delete
                    if (preg_match('#^/admin/app/tiendaonline/lista/(?P<id>[^/]++)/delete$#s', $pathinfo, $matches)) {
                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_app_tiendaonline_lista_delete')), array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::deleteAction',  '_sonata_admin' => 'app_tienda_online.admin.lista',  '_sonata_name' => 'admin_app_tiendaonline_lista_delete',));
                    }

                    // admin_app_tiendaonline_lista_show
                    if (preg_match('#^/admin/app/tiendaonline/lista/(?P<id>[^/]++)/show$#s', $pathinfo, $matches)) {
                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_app_tiendaonline_lista_show')), array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::showAction',  '_sonata_admin' => 'app_tienda_online.admin.lista',  '_sonata_name' => 'admin_app_tiendaonline_lista_show',));
                    }

                    // admin_app_tiendaonline_lista_export
                    if ($pathinfo === '/admin/app/tiendaonline/lista/export') {
                        return array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::exportAction',  '_sonata_admin' => 'app_tienda_online.admin.lista',  '_sonata_name' => 'admin_app_tiendaonline_lista_export',  '_route' => 'admin_app_tiendaonline_lista_export',);
                    }

                }

                if (0 === strpos($pathinfo, '/admin/app/tiendaonline/detallelista')) {
                    // admin_app_tiendaonline_detallelista_list
                    if ($pathinfo === '/admin/app/tiendaonline/detallelista/list') {
                        return array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::listAction',  '_sonata_admin' => 'app_tienda_online.admin.detalle_lista',  '_sonata_name' => 'admin_app_tiendaonline_detallelista_list',  '_route' => 'admin_app_tiendaonline_detallelista_list',);
                    }

                    // admin_app_tiendaonline_detallelista_create
                    if ($pathinfo === '/admin/app/tiendaonline/detallelista/create') {
                        return array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::createAction',  '_sonata_admin' => 'app_tienda_online.admin.detalle_lista',  '_sonata_name' => 'admin_app_tiendaonline_detallelista_create',  '_route' => 'admin_app_tiendaonline_detallelista_create',);
                    }

                    // admin_app_tiendaonline_detallelista_batch
                    if ($pathinfo === '/admin/app/tiendaonline/detallelista/batch') {
                        return array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::batchAction',  '_sonata_admin' => 'app_tienda_online.admin.detalle_lista',  '_sonata_name' => 'admin_app_tiendaonline_detallelista_batch',  '_route' => 'admin_app_tiendaonline_detallelista_batch',);
                    }

                    // admin_app_tiendaonline_detallelista_edit
                    if (preg_match('#^/admin/app/tiendaonline/detallelista/(?P<id>[^/]++)/edit$#s', $pathinfo, $matches)) {
                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_app_tiendaonline_detallelista_edit')), array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::editAction',  '_sonata_admin' => 'app_tienda_online.admin.detalle_lista',  '_sonata_name' => 'admin_app_tiendaonline_detallelista_edit',));
                    }

                    // admin_app_tiendaonline_detallelista_delete
                    if (preg_match('#^/admin/app/tiendaonline/detallelista/(?P<id>[^/]++)/delete$#s', $pathinfo, $matches)) {
                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_app_tiendaonline_detallelista_delete')), array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::deleteAction',  '_sonata_admin' => 'app_tienda_online.admin.detalle_lista',  '_sonata_name' => 'admin_app_tiendaonline_detallelista_delete',));
                    }

                    // admin_app_tiendaonline_detallelista_show
                    if (preg_match('#^/admin/app/tiendaonline/detallelista/(?P<id>[^/]++)/show$#s', $pathinfo, $matches)) {
                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_app_tiendaonline_detallelista_show')), array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::showAction',  '_sonata_admin' => 'app_tienda_online.admin.detalle_lista',  '_sonata_name' => 'admin_app_tiendaonline_detallelista_show',));
                    }

                    // admin_app_tiendaonline_detallelista_export
                    if ($pathinfo === '/admin/app/tiendaonline/detallelista/export') {
                        return array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::exportAction',  '_sonata_admin' => 'app_tienda_online.admin.detalle_lista',  '_sonata_name' => 'admin_app_tiendaonline_detallelista_export',  '_route' => 'admin_app_tiendaonline_detallelista_export',);
                    }

                }

            }

        }

        if (0 === strpos($pathinfo, '/log')) {
            if (0 === strpos($pathinfo, '/login')) {
                // fos_user_security_login
                if ($pathinfo === '/login') {
                    return array (  '_controller' => 'FOS\\UserBundle\\Controller\\SecurityController::loginAction',  '_route' => 'fos_user_security_login',);
                }

                // fos_user_security_check
                if ($pathinfo === '/login_check') {
                    if ($this->context->getMethod() != 'POST') {
                        $allow[] = 'POST';
                        goto not_fos_user_security_check;
                    }

                    return array (  '_controller' => 'FOS\\UserBundle\\Controller\\SecurityController::checkAction',  '_route' => 'fos_user_security_check',);
                }
                not_fos_user_security_check:

            }

            // fos_user_security_logout
            if ($pathinfo === '/logout') {
                return array (  '_controller' => 'FOS\\UserBundle\\Controller\\SecurityController::logoutAction',  '_route' => 'fos_user_security_logout',);
            }

        }

        if (0 === strpos($pathinfo, '/profile')) {
            // fos_user_profile_show
            if (rtrim($pathinfo, '/') === '/profile') {
                if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                    $allow = array_merge($allow, array('GET', 'HEAD'));
                    goto not_fos_user_profile_show;
                }

                if (substr($pathinfo, -1) !== '/') {
                    return $this->redirect($pathinfo.'/', 'fos_user_profile_show');
                }

                return array (  '_controller' => 'FOS\\UserBundle\\Controller\\ProfileController::showAction',  '_route' => 'fos_user_profile_show',);
            }
            not_fos_user_profile_show:

            // fos_user_profile_edit
            if ($pathinfo === '/profile/edit') {
                return array (  '_controller' => 'FOS\\UserBundle\\Controller\\ProfileController::editAction',  '_route' => 'fos_user_profile_edit',);
            }

        }

        if (0 === strpos($pathinfo, '/re')) {
            if (0 === strpos($pathinfo, '/register')) {
                // fos_user_registration_register
                if (rtrim($pathinfo, '/') === '/register') {
                    if (substr($pathinfo, -1) !== '/') {
                        return $this->redirect($pathinfo.'/', 'fos_user_registration_register');
                    }

                    return array (  '_controller' => 'FOS\\UserBundle\\Controller\\RegistrationController::registerAction',  '_route' => 'fos_user_registration_register',);
                }

                if (0 === strpos($pathinfo, '/register/c')) {
                    // fos_user_registration_check_email
                    if ($pathinfo === '/register/check-email') {
                        if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                            $allow = array_merge($allow, array('GET', 'HEAD'));
                            goto not_fos_user_registration_check_email;
                        }

                        return array (  '_controller' => 'FOS\\UserBundle\\Controller\\RegistrationController::checkEmailAction',  '_route' => 'fos_user_registration_check_email',);
                    }
                    not_fos_user_registration_check_email:

                    if (0 === strpos($pathinfo, '/register/confirm')) {
                        // fos_user_registration_confirm
                        if (preg_match('#^/register/confirm/(?P<token>[^/]++)$#s', $pathinfo, $matches)) {
                            if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                                $allow = array_merge($allow, array('GET', 'HEAD'));
                                goto not_fos_user_registration_confirm;
                            }

                            return $this->mergeDefaults(array_replace($matches, array('_route' => 'fos_user_registration_confirm')), array (  '_controller' => 'FOS\\UserBundle\\Controller\\RegistrationController::confirmAction',));
                        }
                        not_fos_user_registration_confirm:

                        // fos_user_registration_confirmed
                        if ($pathinfo === '/register/confirmed') {
                            if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                                $allow = array_merge($allow, array('GET', 'HEAD'));
                                goto not_fos_user_registration_confirmed;
                            }

                            return array (  '_controller' => 'FOS\\UserBundle\\Controller\\RegistrationController::confirmedAction',  '_route' => 'fos_user_registration_confirmed',);
                        }
                        not_fos_user_registration_confirmed:

                    }

                }

            }

            if (0 === strpos($pathinfo, '/resetting')) {
                // fos_user_resetting_request
                if ($pathinfo === '/resetting/request') {
                    if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                        $allow = array_merge($allow, array('GET', 'HEAD'));
                        goto not_fos_user_resetting_request;
                    }

                    return array (  '_controller' => 'FOS\\UserBundle\\Controller\\ResettingController::requestAction',  '_route' => 'fos_user_resetting_request',);
                }
                not_fos_user_resetting_request:

                // fos_user_resetting_send_email
                if ($pathinfo === '/resetting/send-email') {
                    if ($this->context->getMethod() != 'POST') {
                        $allow[] = 'POST';
                        goto not_fos_user_resetting_send_email;
                    }

                    return array (  '_controller' => 'FOS\\UserBundle\\Controller\\ResettingController::sendEmailAction',  '_route' => 'fos_user_resetting_send_email',);
                }
                not_fos_user_resetting_send_email:

                // fos_user_resetting_check_email
                if ($pathinfo === '/resetting/check-email') {
                    if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                        $allow = array_merge($allow, array('GET', 'HEAD'));
                        goto not_fos_user_resetting_check_email;
                    }

                    return array (  '_controller' => 'FOS\\UserBundle\\Controller\\ResettingController::checkEmailAction',  '_route' => 'fos_user_resetting_check_email',);
                }
                not_fos_user_resetting_check_email:

                // fos_user_resetting_reset
                if (0 === strpos($pathinfo, '/resetting/reset') && preg_match('#^/resetting/reset/(?P<token>[^/]++)$#s', $pathinfo, $matches)) {
                    if (!in_array($this->context->getMethod(), array('GET', 'POST', 'HEAD'))) {
                        $allow = array_merge($allow, array('GET', 'POST', 'HEAD'));
                        goto not_fos_user_resetting_reset;
                    }

                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'fos_user_resetting_reset')), array (  '_controller' => 'FOS\\UserBundle\\Controller\\ResettingController::resetAction',));
                }
                not_fos_user_resetting_reset:

            }

        }

        // fos_user_change_password
        if ($pathinfo === '/profile/change-password') {
            if (!in_array($this->context->getMethod(), array('GET', 'POST', 'HEAD'))) {
                $allow = array_merge($allow, array('GET', 'POST', 'HEAD'));
                goto not_fos_user_change_password;
            }

            return array (  '_controller' => 'FOS\\UserBundle\\Controller\\ChangePasswordController::changePasswordAction',  '_route' => 'fos_user_change_password',);
        }
        not_fos_user_change_password:

        throw 0 < count($allow) ? new MethodNotAllowedException(array_unique($allow)) : new ResourceNotFoundException();
    }
}
