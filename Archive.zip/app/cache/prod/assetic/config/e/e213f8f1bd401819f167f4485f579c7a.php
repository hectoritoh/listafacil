<?php

// AppSiteBundle:Default:menu.html.twig
return array (
  'bf46f07' => 
  array (
    0 => 
    array (
      0 => '@AppSiteBundle/Resources/public/img/listafacil/logo2.png',
    ),
    1 => 
    array (
    ),
    2 => 
    array (
      'output' => 'images/bf46f07.png',
      'name' => 'bf46f07',
      'debug' => NULL,
      'combine' => NULL,
      'vars' => 
      array (
      ),
    ),
  ),
);
