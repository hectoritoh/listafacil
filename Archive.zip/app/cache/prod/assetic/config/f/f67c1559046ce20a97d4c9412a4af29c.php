<?php

// AppSiteBundle:Pages:ver.categoria.html.twig
return array (
  'bf46f07' => 
  array (
    0 => 
    array (
      0 => '@AppSiteBundle/Resources/public/img/listafacil/logo2.png',
    ),
    1 => 
    array (
    ),
    2 => 
    array (
      'output' => 'images/bf46f07.png',
      'name' => 'bf46f07',
      'debug' => NULL,
      'combine' => NULL,
      'vars' => 
      array (
      ),
    ),
  ),
  '541cb9d' => 
  array (
    0 => 
    array (
      0 => '@AppSiteBundle/Resources/public/img/photos/2.png',
    ),
    1 => 
    array (
    ),
    2 => 
    array (
      'output' => 'images/541cb9d.png',
      'name' => '541cb9d',
      'debug' => NULL,
      'combine' => NULL,
      'vars' => 
      array (
      ),
    ),
  ),
  'f5bbb76' => 
  array (
    0 => 
    array (
      0 => '@AppSiteBundle/Resources/public/img/hot.png',
    ),
    1 => 
    array (
    ),
    2 => 
    array (
      'output' => 'images/f5bbb76.png',
      'name' => 'f5bbb76',
      'debug' => NULL,
      'combine' => NULL,
      'vars' => 
      array (
      ),
    ),
  ),
  '3f78a7a' => 
  array (
    0 => 
    array (
      0 => '@AppSiteBundle/Resources/public/img/photos/3.png',
    ),
    1 => 
    array (
    ),
    2 => 
    array (
      'output' => 'images/3f78a7a.png',
      'name' => '3f78a7a',
      'debug' => NULL,
      'combine' => NULL,
      'vars' => 
      array (
      ),
    ),
  ),
  '280eebf' => 
  array (
    0 => 
    array (
      0 => '@AppSiteBundle/Resources/public/img/photos/4.png',
    ),
    1 => 
    array (
    ),
    2 => 
    array (
      'output' => 'images/280eebf.png',
      'name' => '280eebf',
      'debug' => NULL,
      'combine' => NULL,
      'vars' => 
      array (
      ),
    ),
  ),
  '10dcd46' => 
  array (
    0 => 
    array (
      0 => '@AppSiteBundle/Resources/public/img/new.png',
    ),
    1 => 
    array (
    ),
    2 => 
    array (
      'output' => 'images/10dcd46.png',
      'name' => '10dcd46',
      'debug' => NULL,
      'combine' => NULL,
      'vars' => 
      array (
      ),
    ),
  ),
  '40fc194' => 
  array (
    0 => 
    array (
      0 => '@AppSiteBundle/Resources/public/img/photos/5.png',
    ),
    1 => 
    array (
    ),
    2 => 
    array (
      'output' => 'images/40fc194.png',
      'name' => '40fc194',
      'debug' => NULL,
      'combine' => NULL,
      'vars' => 
      array (
      ),
    ),
  ),
  '5ff6ed1' => 
  array (
    0 => 
    array (
      0 => '@AppSiteBundle/Resources/public/img/deal.png',
    ),
    1 => 
    array (
    ),
    2 => 
    array (
      'output' => 'images/5ff6ed1.png',
      'name' => '5ff6ed1',
      'debug' => NULL,
      'combine' => NULL,
      'vars' => 
      array (
      ),
    ),
  ),
  '2b74d30' => 
  array (
    0 => 
    array (
      0 => '@AppSiteBundle/Resources/public/img/photos/6.png',
    ),
    1 => 
    array (
    ),
    2 => 
    array (
      'output' => 'images/2b74d30.png',
      'name' => '2b74d30',
      'debug' => NULL,
      'combine' => NULL,
      'vars' => 
      array (
      ),
    ),
  ),
  '6c3190b' => 
  array (
    0 => 
    array (
      0 => '@AppSiteBundle/Resources/public/img/photos/7.png',
    ),
    1 => 
    array (
    ),
    2 => 
    array (
      'output' => 'images/6c3190b.png',
      'name' => '6c3190b',
      'debug' => NULL,
      'combine' => NULL,
      'vars' => 
      array (
      ),
    ),
  ),
  '9f49248' => 
  array (
    0 => 
    array (
      0 => '@AppSiteBundle/Resources/public/img/sale.png',
    ),
    1 => 
    array (
    ),
    2 => 
    array (
      'output' => 'images/9f49248.png',
      'name' => '9f49248',
      'debug' => NULL,
      'combine' => NULL,
      'vars' => 
      array (
      ),
    ),
  ),
  'bc8a856' => 
  array (
    0 => 
    array (
      0 => '@AppSiteBundle/Resources/public/img/photos/8.png',
    ),
    1 => 
    array (
    ),
    2 => 
    array (
      'output' => 'images/bc8a856.png',
      'name' => 'bc8a856',
      'debug' => NULL,
      'combine' => NULL,
      'vars' => 
      array (
      ),
    ),
  ),
  '18bb559' => 
  array (
    0 => 
    array (
      0 => '@AppSiteBundle/Resources/public/img/photos/9.png',
    ),
    1 => 
    array (
    ),
    2 => 
    array (
      'output' => 'images/18bb559.png',
      'name' => '18bb559',
      'debug' => NULL,
      'combine' => NULL,
      'vars' => 
      array (
      ),
    ),
  ),
  '1d90482' => 
  array (
    0 => 
    array (
      0 => '@AppSiteBundle/Resources/public/img/photos/promo-1.png',
    ),
    1 => 
    array (
    ),
    2 => 
    array (
      'output' => 'images/1d90482.png',
      'name' => '1d90482',
      'debug' => NULL,
      'combine' => NULL,
      'vars' => 
      array (
      ),
    ),
  ),
  '58f1854' => 
  array (
    0 => 
    array (
      0 => '@AppSiteBundle/Resources/public/img/photos/promo-2.png',
    ),
    1 => 
    array (
    ),
    2 => 
    array (
      'output' => 'images/58f1854.png',
      'name' => '58f1854',
      'debug' => NULL,
      'combine' => NULL,
      'vars' => 
      array (
      ),
    ),
  ),
  'f432d42' => 
  array (
    0 => 
    array (
      0 => '@AppSiteBundle/Resources/public/img/photos/promo-3.png',
    ),
    1 => 
    array (
    ),
    2 => 
    array (
      'output' => 'images/f432d42.png',
      'name' => 'f432d42',
      'debug' => NULL,
      'combine' => NULL,
      'vars' => 
      array (
      ),
    ),
  ),
  '778cb3e' => 
  array (
    0 => 
    array (
      0 => 'bundles/appsite/style/bootstrap.css',
      1 => 'bundles/appsite/style/font-awesome.min.css',
      2 => 'bundles/appsite/style/jquery.boxslider.css',
      3 => 'bundles/appsite/style/style.css',
      4 => 'bundles/appsite/style/app.css',
    ),
    1 => 
    array (
      0 => 'cssrewrite',
    ),
    2 => 
    array (
      'output' => 'css/778cb3e.css',
      'name' => '778cb3e',
      'debug' => NULL,
      'combine' => NULL,
      'vars' => 
      array (
      ),
    ),
  ),
  '45c404f' => 
  array (
    0 => 
    array (
      0 => '@AppSiteBundle/Resources/public/js/jquery.js',
      1 => '@AppSiteBundle/Resources/public/js/bootstrap.js',
      2 => '@AppSiteBundle/Resources/public/js/jquery.bxslider.min.js',
      3 => '@AppSiteBundle/Resources/public/js/jquery.blImageCenter.js',
      4 => '@AppSiteBundle/Resources/public/js/mimity.js',
    ),
    1 => 
    array (
    ),
    2 => 
    array (
      'output' => 'js/45c404f.js',
      'name' => '45c404f',
      'debug' => NULL,
      'combine' => NULL,
      'vars' => 
      array (
      ),
    ),
  ),
);
