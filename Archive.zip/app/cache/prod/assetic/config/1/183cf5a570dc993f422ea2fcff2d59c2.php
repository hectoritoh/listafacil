<?php

// AppSiteBundle:Default:footer.html.twig
return array (
);
