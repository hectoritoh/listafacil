<?php

namespace App\TiendaOnlineBundle\Controller;

use Sonata\AdminBundle\Controller\CRUDController;

class InstitucionAdminController extends CRUDController
{

}
