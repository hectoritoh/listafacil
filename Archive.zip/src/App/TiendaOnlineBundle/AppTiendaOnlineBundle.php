<?php

namespace App\TiendaOnlineBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class AppTiendaOnlineBundle extends Bundle
{
}
