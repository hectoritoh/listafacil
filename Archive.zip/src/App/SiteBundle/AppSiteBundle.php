<?php

namespace App\SiteBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class AppSiteBundle extends Bundle
{
}
